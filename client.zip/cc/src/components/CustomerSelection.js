import axios from "axios";
import React, { useEffect, useState } from "react";
import { toast, Toaster } from "react-hot-toast";
import { baseUrl } from "./BaseUrl";
import Footer from "./Footer";
import Header from "./Header";
import { Country, State, City } from "country-state-city";

const CustomerSelection = () => {
  const [password, setPassword] = useState("");
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [phone_no, setPhone_no] = useState("");
  const [selectedOptions, setSelectedOptions] = useState("");
  const [stateValue, setStateValue] = useState("");
  const [pincode, setPincode] = useState("");
  const [customerData, setCustomerData] = useState([]);
  const [customerId, setCustomerId] = useState("");
  const [addressData, setAddressData] = useState([]);
  const [isAddUser, setIsAddUser] = useState(false);
  const [isAddressAdd, setIsAddressAdd] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [compneyName, setCompneyName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNo, setPhoneNo] = useState("");
  const [website, setWebsite] = useState("");
  const [gst, setGst] = useState("");
  const [pancard, setPancard] = useState("");
  const [showAddress, setShowAddress] = useState(false);
  const [billingAddress, setBillingAddress] = useState("");
  // const [shippingAddressCust, setShippingAddressCust] = useState("");
  const [formValuesAddUser, setFormValuesAddUser] = useState([
    {
      aName: "",
      aEmail: "",
      aPhoneNo: "",
      designation: "",
      selected: "",
    },
  ]);

  const [formValuesAddressUser, setFormValuesAddressUser] = useState([
    {
      address: "",
      country: "",
      phone_no: "",
      city: "",
      zipcode: "",
      state: "",
    },
  ]);
  const [formValues, setFormValues] = useState([
    {
      aName: "",
      aEmail: "",
      aPhoneNo: "",
      designation: "",
      selected: "",
    },
  ]);

  const [formValuesAddress, setFormValuesAddress] = useState([
    {
      address: "",
      country: "",
      phone_no: "",
      city: "",
      zipcode: "",
      state: "",
    },
  ]);
  // const [addressId, setAddressId] = useState("");
  const [isDetailsShow, setIsDetailsShow] = useState(false);
  const [customerDataById, setCustomerDataById] = useState([]);
  useEffect(() => {
    getCustomer();
  }, []);
  const getCustomer = () => {
    const config = {
      headers: {
        Authorization: `Bearer + ${localStorage.getItem("jwtToken")}`,
      },
    };
    axios.get(baseUrl + "/frontapi/get-customer", {}, config).then((res) => {
      var resp = res.data;
      if (resp.status === true) {
        setCustomerData(resp.data);
      }
    });
  };

  const getAddressList = (id) => {
    const config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("jwtToken")}`,
      },
    };
    let customerDataById = {
      customerId: id,
    };
    axios
      .post(baseUrl + "/frontapi/get-address-byid", customerDataById, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === true) {
          setAddressData(resp.data);
        }
      });
  };

  const getCustomerDetails = (id, addId) => {
    const config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("jwtToken")}`,
      },
    };
    let customerDataById = {
      customerId: id,
      addId: addId,
    };
    axios
      .post(baseUrl + "/frontapi/get-customer-byid", customerDataById, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === true) {
          setCustomerDataById(resp.data);
        }
      });
  };

  const customerDetailsHtml = () => {
    const html = [];
    customerDataById.map((value) => {
      return html.push(
        <div className="customer-detail-outer">
          <ul className="nav">
            <li>
              Customer Name : <b>{value.name}</b>
            </li>
            <li>
              Company Name : <b>{value.companyName}</b>
            </li>
            <li>
              Email : <b>{value.email}</b>
            </li>
            <li>
              Pan Number : <b>{value.panNumber}</b>
            </li>
            <li>
              Phone Number : <b>{value.phoneNumber}</b>
            </li>
            <li>
              Billing Address : <b>{value.billingAddress}</b>
            </li>
            <li>
              Country: <b> {value.country}</b>
            </li>
            <li>
              State: <b> {value.state}</b>
            </li>
            <li>
              City: <b> {value.city}</b>
            </li>
            <li>
              Pincode: <b> {value.pincode}</b>
            </li>
            <li>
              Website : <b>{value.website}</b>
            </li>
          </ul>
          <ul className="nav other-address">
            <h5 className="w-100">Shipping Address :</h5>{" "}
            {attributeCheck(value)}
          </ul>
        </div>
      );
    });
    return html;
  };

  const attributeCheck = (value) => {
    return value.att.map((element, index) => {
      return (
        <>
          <li>
            Address: <b> {element.address}</b>
          </li>
          <li>
            Country: <b> {element.country}</b>
          </li>
          <li>
            State: <b> {element.state}</b>
          </li>
          <li>
            City: <b> {element.city}</b>
          </li>
          <li>
            Phone No: <b> {element.phone_no}</b>
          </li>
          <li>
            Pincode: <b> {element.zipcode}</b>
          </li>
        </>
      );
    });
  };

  const handleChangeBillingAddress = (event) => {
    let { name, value } = event.target;

    if (name === "country") {
      setCountry(value);
      return false;
    }
    if (name === "billingAddress") {
      setBillingAddress(value);
      return false;
    }
    if (name === "state") {
      setStateValue(value);
      return false;
    }
    if (name === "city") {
      setCity(value);
      return false;
    }
    if (name === "zipcode") {
      setPincode(value);
      return false;
    }
    if (name === "phone_no") {
      setPhone_no(value);
      return false;
    }
  };

  const handleChangeOptions = (e) => {
    let { name } = e.target;
    if (name === "buisness") {
      setSelectedOptions(name);
    }
    if (name === "manufacturer") {
      setSelectedOptions(name);
    }
    if (name === "individual") {
      setSelectedOptions(name);
    }
  };

  const generatePassword = (e) => {
    e.preventDefault();
    var chars =
      "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var passwordLength = 12;
    var password = "";
    for (var i = 0; i <= passwordLength; i++) {
      var randomNumber = Math.floor(Math.random() * chars.length);
      password += chars.substring(randomNumber, randomNumber + 1);
    }
    setPassword(password);
  };

  const countryDropDownHtml = () => {
    const html = [];
    const country = Country.getAllCountries();
    country.map((country) => {
      return html.push(
        <option key={country.name} value={country.isoCode}>
          {country.name}
        </option>
      );
    });
    return html;
  };
  const stateDropDownHtml = () => {
    const html = [];
    const states = State.getStatesOfCountry(country);
    states.map((state) => {
      return html.push(
        <option key={state.name} value={state.name}>
          {state.name}
        </option>
      );
    });
    return html;
  };

  const handleChange = (e) => {
    let { name, value } = e.target;
    if (name === "customerId") {
      if (!value) {
        closeAddress();
        setShowAddress(false);
        return false;
      }
      setCustomerId(value);
      getAddressList(value);
      setShowAddress(true);
    }
    if (name === "addressId") {
      // setAddressId(value);
      setIsDetailsShow(true);
      getCustomerDetails(customerId, value);
    }
    if (name === "customerName") {
      setCustomerName(value);
    }
    if (name === "companyName") {
      setCompneyName(value);
    }
    if (name === "email") {
      setEmail(value);
    }
    if (name === "pNumber") {
      setPhoneNo(value);
    }
    if (name === "website") {
      setWebsite(value);
    }
    if (name === "gst") {
      setGst(value);
    }
    if (name === "panNum") {
      setPancard(value);
    }
  };

  const handleChangeAttrUser = (i, e) => {
    let newFormValues = [...formValuesAddUser];
    newFormValues[i][e.target.name] = e.target.value;
    setFormValuesAddUser(newFormValues);
  };

  const addFormFieldsUser = () => {
    setFormValuesAddUser([...formValuesAddUser, {}]);
  };
  let removeFormFieldsUser = (i) => {
    let newFormValues = [...formValuesAddUser];
    newFormValues.splice(i, 1);
    setFormValuesAddUser(newFormValues);
  };

  let handleChangeAddressUser = (i, e) => {
    let newFormValues = [...formValuesAddressUser];
    newFormValues[i][e.target.name] = e.target.value;
    setFormValuesAddressUser(newFormValues);
  };
  let addFormFieldsAddressUser = () => {
    setFormValuesAddressUser([...formValuesAddressUser, {}]);
  };

  let removeFormFieldsAddressUser = (i) => {
    let newFormValues = [...formValuesAddressUser];
    newFormValues.splice(i, 1);
    setFormValuesAddressUser(newFormValues);
  };

  let handleChangeAddress = (i, e) => {
    let newFormValues = [...formValuesAddress];
    newFormValues[i][e.target.name] = e.target.value;
    setFormValuesAddress(newFormValues);
  };
  let addFormFieldsAddress = () => {
    setFormValuesAddress([...formValuesAddress, {}]);
  };

  let removeFormFieldsAddress = (i) => {
    let newFormValues = [...formValuesAddress];
    newFormValues.splice(i, 1);
    setFormValuesAddress(newFormValues);
  };

  const handleChangeAttr = (i, e) => {
    let newFormValues = [...formValues];
    newFormValues[i][e.target.name] = e.target.value;
    setFormValues(newFormValues);
  };

  const addFormFields = () => {
    setFormValues([...formValues, {}]);
  };
  let removeFormFields = (i) => {
    let newFormValues = [...formValues];
    newFormValues.splice(i, 1);
    setFormValues(newFormValues);
  };

  const countryShippingDropDownHtml = () => {
    const html = [];
    const country = Country.getAllCountries();
    country.map((country) => {
      return html.push(
        <option key={country.name} value={country.isoCode}>
          {country.name}
        </option>
      );
    });
    return html;
  };

  const stateShippingDropDownHtml = (i) => {
    const html = [];
    const states = State.getStatesOfCountry(formValuesAddress[i].country);
    states.map((state) => {
      return html.push(
        <option key={state.name} value={state.name}>
          {state.name}
        </option>
      );
    });
    return html;
  };

  const countryShippingDropDownHtmlUser = () => {
    const html = [];
    const country = Country.getAllCountries();
    country.map((country) => {
      return html.push(
        <option key={country.name} value={country.isoCode}>
          {country.name}
        </option>
      );
    });
    return html;
  };

  const stateShippingDropDownHtmlUser = (i) => {
    const html = [];
    const states = State.getStatesOfCountry(formValuesAddressUser[i].country);
    states.map((state) => {
      return html.push(
        <option key={state.name} value={state.name}>
          {state.name}
        </option>
      );
    });
    return html;
  };

  const customerListHtml = () => {
    const html = [];
    html.push(<option value="">Select</option>);
    customerData.map((value) => {
      return html.push(<option value={value.id}>{value.name}</option>);
    });
    return (
      <select
        className="form-control"
        name="customerId"
        onChange={handleChange}
      >
        {html}
      </select>
    );
  };

  const addressListHtml = () => {
    const html = [];
    html.push(<option value="">Select</option>);
    addressData.map((value) => {
      return html.push(<option value={value.id}>{value.address}</option>);
    });
    return (
      <select className="form-control" name="addressId" onChange={handleChange}>
        {html}
      </select>
    );
  };

  const addCustomer = () => {
    setIsAddUser(!isAddUser);
    setCustomerName("");
    setCompneyName("");
    setEmail("");
    setPhoneNo("");
    setWebsite("");
    setGst("");
    setPancard("");
    setBillingAddress("");
    // setShippingAddressCust("");
  };

  const addAddress = () => {
    setIsAddressAdd(!isAddressAdd);
  };

  const addCustomerData = () => {
    const config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("jwtToken")}`,
      },
    };
    let customerData = {
      selectedOptions: selectedOptions,
      customerName: customerName,
      companyName: compneyName,
      email: email,
      phoneNo: phoneNo,
      website: website,
      gst: gst,
      pancard: pancard,
      // password: password,
      billingAddress: billingAddress,
      country: country,
      city: city,
      stateValue: stateValue,
      phone_no: phone_no,
      pincode: pincode,
      atribute: formValues,
      address: formValuesAddress,
    };

    axios
      .post(baseUrl + "/frontapi/add-user-service", customerData, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === true) {
          getCustomer();
          toast.dismiss();
          toast.success(resp.message);
          setIsAddUser(false);
          setCustomerName("");
          setCompneyName("");
          setEmail("");
          setPhoneNo("");
          setWebsite("");
          setGst("");
          setPancard("");
          setBillingAddress("");
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const closeAddress = () => {
    setIsAddressAdd(false);
  };

  const addAddressData = () => {
    const config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("jwtToken")}`,
      },
    };
    if (customerId === "") {
      toast.dismiss();
      toast.error("Please select user first");
      return false;
    }
    let customerData = {
      customerId: customerId,
      atribute: formValuesAddUser,
      address: formValuesAddressUser,
    };

    axios
      .post(baseUrl + "/frontapi/add-address-service", customerData, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === true) {
          toast.dismiss();
          toast.success(resp.message);
          setIsAddressAdd(false);
          setFormValuesAddUser([
            {
              aName: "",
              aEmail: "",
              aPhoneNo: "",
              designation: "",
              selected: "",
            },
          ]);
          getAddressList(customerId);
          return false;
        }
        toast.dismiss();
        toast.error(resp.message);
      });
  };

  const submitData = async () => {
    if (!customerId) {
      toast.error("Please select user or add first");
      return false;
    }
    let params = {
      customerId: customerId,
    };
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios
      .post(baseUrl + "/frontapi/placeOrderSalcePerson", params, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          toast.success("Order placed  successfully");
          setTimeout(function () {
            window.location = "/checkout-success";
          }, 2000);
          return false;
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
    return;
  };

  return (
    <div>
      <Header />
      <div className="select-customer-outer">
        <div className="container">
          <div className="select-form-outer">
            <div className="row">
              <div className="col-md-6 col-12">
                <label>Please select customer</label>
                <div className="form-group">{customerListHtml()}</div>
                <a href="#!" onClick={addCustomer} className="btn btn-primary">
                  + Add User
                </a>
              </div>
              <div className="col-md-6 col-12">
                <label>Please select address</label>
                <div className="form-group">{addressListHtml()}</div>

                {showAddress === true && (
                  <a href="#!" onClick={addAddress} className="btn btn-primary">
                    + Add Address
                  </a>
                )}
              </div>
            </div>
          </div>
          {isDetailsShow === true && customerDetailsHtml()}
          {/* Customer Add Model */}
          {isAddUser === true && (
            <div className="add-user-form-main">
              <form>
                <div className="row">
                  <div className="col-4">
                    <div className="form-group">
                      <input
                        type="radio"
                        name="buisness"
                        value={selectedOptions}
                        checked={selectedOptions === "buisness" && true}
                        id="buisness"
                        onChange={handleChangeOptions}
                      />
                      <label className="radio-label" htmlFor="buisness">
                        Business
                      </label>
                    </div>
                  </div>
                  <div className="col-4">
                    <div className="form-group">
                      <input
                        type="radio"
                        value={selectedOptions}
                        name="manufacturer"
                        checked={selectedOptions === "manufacturer" && true}
                        id="manufacturer"
                        onChange={handleChangeOptions}
                      />
                      <label className="radio-label" htmlFor="manufacturer">
                        Manufacturer
                      </label>
                    </div>
                  </div>
                  <div className="col-4">
                    <div className="form-group">
                      <input
                        type="radio"
                        name="individual"
                        value={selectedOptions}
                        checked={selectedOptions === "individual" && true}
                        id="individual"
                        onChange={handleChangeOptions}
                      />
                      <label className="radio-label" htmlFor="individual">
                        Individual
                      </label>
                    </div>
                  </div>
                  <div className="col-md-4 col-sm-6 col-12">
                    <div className="form-group">
                      <label>Customer Name</label>
                      <input
                        type="text"
                        name="customerName"
                        placeholder=""
                        className="form-control"
                        onChange={handleChange}
                        // onBlur={handleOnBlurCustomerName}
                      />
                    </div>
                  </div>
                  <div className="col-md-4 col-sm-6 col-12">
                    <div className="form-group">
                      <label>Company Name</label>
                      <input
                        type="text"
                        name="companyName"
                        placeholder=""
                        className="form-control"
                        onChange={handleChange}
                        // onBlur={handleOnBlurCompanyName}
                      />
                    </div>
                  </div>
                  <div className="col-md-4 col-sm-6 col-12">
                    <div className="form-group">
                      <label>Email</label>
                      <input
                        type="email"
                        name="email"
                        placeholder=""
                        className="form-control"
                        onChange={handleChange}
                        // onBlur={handleOnBlurEmail}
                      />
                    </div>
                  </div>
                  <div className="col-md-4 col-sm-6 col-12">
                    <div className="form-group">
                      <label>Password</label>
                      <input
                        type="text"
                        name="password"
                        placeholder=""
                        disabled
                        value={password}
                        className="form-control"
                        onChange={handleChange}
                        // onBlur={handleOnBlurPassword}
                      />
                      <div className="generate-pass-btn">
                        <button
                          className="btn btn-primary"
                          onClick={generatePassword}
                        >
                          Generate Password
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-4 col-sm-6 col-12">
                    <div className="form-group">
                      <label>Phone Number</label>
                      <input
                        type="number"
                        name="pNumber"
                        placeholder=""
                        className="form-control"
                        onChange={handleChange}
                        // onBlur={handleOnBlurPhoneNum}
                      />
                    </div>
                  </div>
                  <div className="col-md-4 col-sm-6 col-12">
                    <div className="form-group">
                      <label>Website</label>
                      <input
                        type="text"
                        name="website"
                        placeholder=""
                        className="form-control"
                        onChange={handleChange}
                        // onBlur={handleOnBlurWebsite}
                      />
                    </div>
                  </div>
                  <div className="col-md-6 col-sm-6 col-12">
                    <div className="form-group">
                      <label>GST</label>
                      <input
                        type="gst"
                        name="gst"
                        placeholder=""
                        className="form-control"
                        onChange={handleChange}
                        // onBlur={handleOnBlurGst}
                      />
                    </div>
                  </div>
                  <div className="col-md-6 col-sm-6 col-12">
                    <div className="form-group">
                      <label>PAN Number</label>
                      <input
                        type="text"
                        name="panNum"
                        placeholder=""
                        className="form-control"
                        onChange={handleChange}
                        // onBlur={handleOnBlurPanNum}
                      />
                    </div>
                  </div>
                  <div className="billing-shipping d-flex flex-wrap">
                    <div className="col-md-6 col-12 padding-left">
                      <h4> Billing Address</h4>
                      <div className="col-12">
                        <div className="form-group">
                          <label>Country</label>
                          <select
                            type="text"
                            name="country"
                            value={country}
                            placeholder=""
                            className="form-control"
                            onChange={handleChangeBillingAddress}
                          >
                            <option>Select Country</option>
                            {countryDropDownHtml()}
                          </select>
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label>Address</label>
                          <input
                            type="text"
                            name="billingAddress"
                            value={billingAddress}
                            placeholder=""
                            className="form-control"
                            onChange={handleChangeBillingAddress}
                            // onBlur={handleOnBlurBillingAddress}
                          />
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label>State</label>
                          <select
                            type="text"
                            name="state"
                            value={stateValue}
                            placeholder=""
                            className="form-control"
                            onChange={handleChangeBillingAddress}
                          >
                            <option>Select State</option>
                            {stateDropDownHtml()}
                          </select>
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label>City</label>
                          <input
                            type="text"
                            name="city"
                            value={city}
                            placeholder=""
                            className="form-control"
                            onChange={handleChangeBillingAddress}
                          />
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label>Pincode</label>
                          <input
                            type="number"
                            name="zipcode"
                            value={pincode}
                            placeholder=""
                            className="form-control"
                            onChange={handleChangeBillingAddress}
                          />
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label>Phone No.</label>
                          <input
                            type="number"
                            name="phone_no"
                            value={phone_no}
                            placeholder=""
                            className="form-control"
                            onChange={handleChangeBillingAddress}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6 col-12 padding-right">
                      <h4> Shipping Address</h4>

                      {formValuesAddress.map((element, index) => (
                        <>
                          <div className="col-12">
                            <div className="form-group">
                              <label>Country</label>
                              <select
                                className="form-control"
                                name="country"
                                onChange={(e) => handleChangeAddress(index, e)}
                              >
                                <option>Select Country</option>
                                {countryShippingDropDownHtml()}
                              </select>
                            </div>
                          </div>
                          <div className="col-12">
                            <div className="form-group">
                              <label>Address</label>
                              <input
                                type="text"
                                name="address"
                                className="form-control"
                                value={element.address || ""}
                                onChange={(e) => handleChangeAddress(index, e)}
                              />
                            </div>
                          </div>
                          <div className="col-12">
                            <div className="form-group">
                              <label>State</label>
                              <select
                                className="form-control"
                                name="state"
                                onChange={(e) => handleChangeAddress(index, e)}
                              >
                                <option>Select State</option>
                                {stateShippingDropDownHtml(index)}
                              </select>
                            </div>
                          </div>
                          <div className="col-12">
                            <div className="form-group">
                              <label>City</label>
                              <input
                                type="text"
                                name="city"
                                className="form-control"
                                value={element.city || ""}
                                onChange={(e) => handleChangeAddress(index, e)}
                              />
                            </div>
                          </div>
                          <div className="col-12">
                            <div className="form-group">
                              <label>Pincode</label>
                              <input
                                className="form-control"
                                type="number"
                                name="zipcode"
                                onChange={(e) => handleChangeAddress(index, e)}
                                value={element.zipcode || ""}
                              />
                            </div>
                          </div>
                          <div className="col-12">
                            <div className="add-row-group d-flex align-items-center justify-content-between">
                              <div className="form-group">
                                <label>Phone No.</label>
                                <input
                                  type="number"
                                  name="phone_no"
                                  className="form-control"
                                  value={element.phone_no || ""}
                                  onChange={(e) =>
                                    handleChangeAddress(index, e)
                                  }
                                />
                              </div>

                              <div className="add-row btn-group">
                                {index ? (
                                  <a
                                    className="remove btn btn-primary"
                                    onClick={() =>
                                      removeFormFieldsAddress(index)
                                    }
                                    href="#!"
                                  >
                                    -
                                  </a>
                                ) : null}
                                <a
                                  href="#!"
                                  onClick={() => addFormFieldsAddress()}
                                  className="btn btn-primary"
                                >
                                  +
                                </a>
                              </div>
                            </div>
                          </div>
                        </>
                      ))}
                    </div>
                  </div>
                  <div className="col-12">
                    <div className="contact-person-heading">
                      <h5>Contact Person</h5>
                    </div>
                  </div>
                  {formValues.map((element, index) => (
                    <>
                      <div className="col-md-3 col-sm-6 col-12 order-1">
                        <div className="form-group">
                          <label>Name</label>
                          <input
                            type="text"
                            name="aName"
                            className="form-control"
                            value={element.aName || ""}
                            onChange={(e) => handleChangeAttr(index, e)}
                          />
                        </div>
                      </div>
                      <div className="col-md-3 col-sm-6 col-12 order-1">
                        <div className="form-group">
                          <label>Phone No.</label>
                          <input
                            type="text"
                            name="aPhoneNo"
                            placeholder=""
                            className="form-control"
                            value={element.aPhoneNo || ""}
                            onChange={(e) => handleChangeAttr(index, e)}
                          />
                        </div>
                      </div>
                      <div className="col-md-3 col-sm-6 col-12 order-1">
                        <div className="form-group">
                          <label>Designation</label>
                          <select
                            className="form-control"
                            value={element.selected || ""}
                            onChange={(e) => handleChangeAttr(index, e)}
                            name="selected"
                          >
                            <option>Select</option>
                            <option>HR/Admin Manager</option>
                            <option>Procurement Manager</option>
                            <option>General Manager</option>
                            <option>Owner/Partner/Director</option>
                            <option>Store Manager</option>
                            <option>Marketing Manager</option>
                            <option>Other</option>
                          </select>
                          {element.selected === "Other" && (
                            <input
                              type="text"
                              name="designation"
                              placeholder=""
                              className="form-control"
                              value={element.designation || ""}
                              onChange={(e) => handleChangeAttr(index, e)}
                            />
                          )}
                        </div>
                      </div>
                      <div className="col-md-3 col-sm-6 col-12 order-1">
                        <div className="add-row-group d-flex align-items-center justify-content-between">
                          <div className="form-group">
                            <label>Email.</label>
                            <input
                              type="text"
                              name="aEmail"
                              placeholder=""
                              className="form-control"
                              value={element.aEmail || ""}
                              onChange={(e) => handleChangeAttr(index, e)}
                            />
                          </div>

                          <div className="add-row btn-group">
                            {index ? (
                              <a
                                className="remove btn btn-primary"
                                onClick={() => removeFormFields(index)}
                                href="#!"
                              >
                                -
                              </a>
                            ) : null}
                            <a
                              href="#!"
                              onClick={() => addFormFields()}
                              className="btn btn-primary"
                            >
                              +
                            </a>
                          </div>
                        </div>
                      </div>
                    </>
                  ))}
                </div>
              </form>
              <div className="btn-group">
                <button
                  type="button"
                  class="btn btn-primary"
                  onClick={addCustomerData}
                >
                  {" "}
                  Save{" "}
                </button>
                <button
                  type="button"
                  class="btn btn-primary"
                  onClick={addCustomer}
                >
                  {" "}
                  Cancel{" "}
                </button>
              </div>
            </div>
          )}
          {isAddressAdd === true && (
            <div className="add-address-form-main">
              <div className="col-md-6 col-12 padding-right">
                <h4> Shipping Address</h4>

                {formValuesAddressUser.map((element, index) => (
                  <>
                    <div className="col-12">
                      <div className="form-group">
                        <label>Country</label>
                        <select
                          className="form-control"
                          name="country"
                          onChange={(e) => handleChangeAddressUser(index, e)}
                        >
                          <option>Select Country</option>
                          {countryShippingDropDownHtmlUser()}
                        </select>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>Address</label>
                        <input
                          type="text"
                          name="address"
                          className="form-control"
                          value={element.address || ""}
                          onChange={(e) => handleChangeAddressUser(index, e)}
                        />
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>State</label>
                        <select
                          className="form-control"
                          name="state"
                          onChange={(e) => handleChangeAddressUser(index, e)}
                        >
                          <option>Select State</option>
                          {stateShippingDropDownHtmlUser(index)}
                        </select>
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>City</label>
                        <input
                          type="text"
                          name="city"
                          className="form-control"
                          value={element.city || ""}
                          onChange={(e) => handleChangeAddressUser(index, e)}
                        />
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label>Pincode</label>
                        <input
                          className="form-control"
                          type="number"
                          name="zipcode"
                          onChange={(e) => handleChangeAddressUser(index, e)}
                          value={element.zipcode || ""}
                        />
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="add-row-group d-flex align-items-center justify-content-between">
                        <div className="form-group">
                          <label>Phone No.</label>
                          <input
                            type="number"
                            name="phone_no"
                            className="form-control"
                            value={element.phone_no || ""}
                            onChange={(e) => handleChangeAddressUser(index, e)}
                          />
                        </div>
                        <div className="add-row btn-group">
                          {index ? (
                            <a
                              className="remove btn btn-primary"
                              onClick={() => removeFormFieldsAddressUser(index)}
                              href="#!"
                            >
                              -
                            </a>
                          ) : null}
                          <a
                            href="#!"
                            onClick={() => addFormFieldsAddressUser()}
                            className="btn btn-primary"
                          >
                            +
                          </a>
                        </div>
                      </div>
                    </div>
                  </>
                ))}
              </div>

              {formValuesAddUser.map((element, index) => (
                <form>
                  <div className="row">
                    <div class="col-md-4 col-sm-6 col-12">
                      <div class="form-group">
                        <label>Name</label>
                        <input
                          type="text"
                          name="aName"
                          placeholder=""
                          class="form-control"
                          value={element.aName || ""}
                          onChange={(e) => handleChangeAttrUser(index, e)}
                        />
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-12">
                      <div class="form-group">
                        <label>Phone No.</label>
                        <input
                          type="text"
                          name="aPhoneNo"
                          placeholder=""
                          class="form-control"
                          value={element.aPhoneNo || ""}
                          onChange={(e) => handleChangeAttrUser(index, e)}
                        />
                      </div>
                    </div>
                    <div className="col-md-3 col-sm-6 col-12 order-1">
                      <div className="form-group">
                        <label>Designation</label>
                        <select
                          className="form-control"
                          value={element.selected || ""}
                          onChange={(e) => handleChangeAttrUser(index, e)}
                          name="selected"
                        >
                          <option>Select</option>
                          <option>HR/Admin Manager</option>
                          <option>Procurement Manager</option>
                          <option>General Manager</option>
                          <option>Owner/Partner/Director</option>
                          <option>Store Manager</option>
                          <option>Marketing Manager</option>
                          <option>Other</option>
                        </select>
                        {element.selected === "Other" && (
                          <input
                            type="text"
                            name="designation"
                            placeholder=""
                            className="form-control"
                            value={element.designation || ""}
                            onChange={(e) => handleChangeAttr(index, e)}
                          />
                        )}
                      </div>
                    </div>
                    <div className="col-md-4 col-sm-6 col-12">
                      <div className="add-row-group d-flex align-items-center justify-content-between">
                        <div className="form-group">
                          <label>Email.</label>
                          <input
                            type="text"
                            name="aEmail"
                            placeholder=""
                            value={element.aEmail || ""}
                            onChange={(e) => handleChangeAttrUser(index, e)}
                            className="form-control"
                          />
                        </div>

                        <div className="add-row btn-group">
                          {index ? (
                            <a
                              className="remove btn btn-primary"
                              onClick={() => removeFormFieldsUser(index)}
                              href="#!"
                            >
                              -
                            </a>
                          ) : null}
                          <a
                            href="#!"
                            onClick={() => addFormFieldsUser()}
                            className="btn btn-primary"
                          >
                            +
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              ))}
              <div className="btn-group">
                <button
                  type="button"
                  class="btn btn-primary"
                  onClick={addAddressData}
                >
                  {" "}
                  Save{" "}
                </button>
                <button
                  type="button"
                  class="btn btn-primary"
                  onClick={closeAddress}
                >
                  {" "}
                  Cancel{" "}
                </button>
              </div>
            </div>
          )}
          <div className="place-btn-outer">
            <button className="btn btn-primary  " onClick={submitData}>
              Place order
            </button>
          </div>
        </div>
      </div>
      <Footer />
      <Toaster />
    </div>
  );
};

export default CustomerSelection;

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Toaster, toast } from "react-hot-toast";
import "react-toastify/dist/ReactToastify.css";
import * as myConstList from "./BaseUrl";

const baseUrl = myConstList.baseUrl;

function Footer(props) {
  const [count, setCount] = useState("");
  const [data, setData] = useState([]);

  useEffect(() => {
    productListByCart();
    productCout();
  }, [props]);

  const DecreaseMargin = async (value) => {
    let params = {
      productId: value.id,
      cartId: value.cartId,
    };
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios
      .post(baseUrl + "/frontapi/deleteCartANDCheck", params, config)
      .then((res) => {
        var resp = res.data;

        if (resp.status) {
          props.setRefreshed(new Date().getTime());
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const IncrementMargin = (value) => {
    let params = {
      productId: value.id,
      cartId: value.cartId,
      qty: 1,
    };
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    axios
      .post(baseUrl + "/frontapi/update-cart", params, config)
      .then((res) => {
        var resp = res.data;

        if (resp.status) {
          props.setRefreshed(new Date().getTime());
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const productCout = () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    axios.post(baseUrl + "/frontapi/product-count", {}, config).then((res) => {
      var resp = res.data;
      if (resp.status === false) {
        toast.dismiss();
        toast.error(resp.message);
        return;
      }
      if (resp.status === true) {
        setCount(resp.data.length);
      }
    });
  };
  const productListByCart = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios
      .post(baseUrl + "/frontapi/get-cart-by-userid", {}, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          setData(resp.data);
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const deleteCartByUserid = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };

    await axios
      .post(baseUrl + "/frontapi/deleteCartByUserid", {}, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          props.setRefreshed(true);
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };
  let total = 0;
  const dataHtml = (data) => {
    const html = [];
    data.map(function (value, i) {
      total = total + value.price * value.qty;
      return html.push(
        <li className="item d-flex justify-content-center align-items-center">
          <a className="product-image" href="product-layout.html">
            <img
              className="blur-up lazyload"
              src={baseUrl + "/static" + value.image}
              data-src={baseUrl + "/static" + value.image}
              alt=""
              title=""
              width={100}
              height={120}
            />
          </a>
          <div className="product-details">
            <Link className="product-title" to={"/product-detail/" + value.id}>
              {value.name}
            </Link>
            <div className="variant-cart">Black / XL</div>
            <div className="priceRow">
              <div className="product-price">
                <span className="money">₹{value.price}</span>
              </div>
            </div>
          </div>
          <div className="qtyDetail text-center">
            <div className="wrapQtyBtn">
              <div className="qtyField">
                <button
                  className="qtyBtn minus"
                  type="button"
                  onClick={() => DecreaseMargin(value)}
                >
                  -
                </button>
                <input
                  type="text"
                  name="quantity"
                  defaultValue={value.qty}
                  value={value.qty}
                  className="qty"
                />
                <button
                  className="qtyBtn plus"
                  type="button"
                  onClick={() => IncrementMargin(value)}
                >
                  +
                </button>
              </div>
            </div>
            <a href="#!" className="edit-i remove">
              <i
                className="icon an an-edit-l"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Edit"
              />
            </a>
            <a href="#!" className="remove" onClick={deleteCartByUserid}>
              <i
                className="an an-times-r"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Remove"
              />
            </a>
          </div>
        </li>
      );
    });
    return html;
  };
  return (
    <>
      {/*Footer*/}
      <div className="footer footer-1">
        <div className="footer-top clearfix">
          <div className="container">
            <div className="row">
              <div className="col-12 col-sm-12 col-md-12 col-lg-12 text-center about-col">
                <img
                  src="../../assets/images/logo.png"
                  alt="Procur"
                  className="mb-3 img-fluid"
                />
                <p>55 Gallaxy Enque, 2568 steet, 23568 NY</p>
                <p className="mb-0 mb-md-0">
                  Phone: <a href="tel:+011234567890">(+01) 123 456 7890</a>{" "}
                  <span className="mx-1">|</span> Email:{" "}
                  <a href="mailto:info@example.com">info@example.com</a>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="footer-bottom clearfix">
          <div className="container">
            <div className="d-flex-center flex-column justify-content-center flex-md-row-reverse">
              <div className="copytext text-uppercase">
                © 2022 Procur.it. All Rights Reserved.
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*End Footer*/}
      {/*Sticky Menubar Mobile*/}
      <div className="menubar-mobile d-flex align-items-center justify-content-between d-lg-none">
        <div className="menubar-shop menubar-item">
          <a href="category-4columns.html">
            <i className="menubar-icon an an-th-large-l" />
            <span className="menubar-label">Shop</span>
          </a>
        </div>
        <div className="menubar-account menubar-item">
          <a href="my-account.html">
            <span className="menubar-icon an an-user-expand" />
            <span className="menubar-label">Account</span>
          </a>
        </div>
        <div className="menubar-search menubar-item">
          <a href="index.html">
            <span className="menubar-icon an an-home-l" />
            <span className="menubar-label">Home</span>
          </a>
        </div>
        <div className="menubar-wish menubar-item">
          <a href="my-wishlist.html">
            <span className="span-count position-relative text-center">
              <span className="menubar-icon an an-heart-l" />
              <span className="menubar-count counter d-flex-center justify-content-center position-absolute translate-middle rounded-circle">
                0
              </span>
            </span>
            <span className="menubar-label">Wishlist</span>
          </a>
        </div>
        <div className="menubar-cart menubar-item">
          <a
            href="cart.html"
            className="cartBtn"
            data-bs-toggle="modal"
            data-bs-target="#minicart-drawer"
          >
            <span className="span-count position-relative text-center">
              <span className="menubar-icon an an-sq-bag" />
              <span className="menubar-count counter d-flex-center justify-content-center position-absolute translate-middle rounded-circle">
                2
              </span>
            </span>
            <span className="menubar-label">Cart</span>
          </a>
        </div>
      </div>
      {/*End Sticky Menubar Mobile*/}
      {/*Scoll Top*/}
      <span id="site-scroll">
        <i className="icon an an-chevron-up" />
      </span>
      {/*End Scoll Top*/}
      {/*MiniCart Drawer*/}
      <div
        className="minicart-right-drawer modal right fade"
        id="minicart-drawer"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            {/*MiniCart Empty*/}
            <div
              id="cartEmpty"
              className="cartEmpty d-flex-justify-center flex-column text-center p-3 text-muted d-none"
            >
              <div className="minicart-header d-flex-center justify-content-between w-100">
                <h4 className="fs-6">Your cart (0 Items)</h4>
                <a
                  href="#!;"
                  className="close-cart"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                >
                  <i
                    className="an an-times-r"
                    aria-hidden="true"
                    data-bs-toggle="tooltip"
                    data-bs-placement="left"
                    title="Close"
                  />
                </a>
              </div>
              <div className="cartEmpty-content mt-4">
                <i className="icon an an-sq-bag fs-1 text-muted" />
                <p className="my-3">No Products in the Cart</p>
                <a
                  href="category-4columns.html"
                  className="btn btn-primary cart-btn rounded"
                >
                  Continue shopping
                </a>
              </div>
            </div>
            {/*End MiniCart Empty*/}
            {/*MiniCart Content*/}
            <div id="cart-drawer" className="block block-cart">
              <div className="minicart-header">
                <a
                  href="#!"
                  className="close-cart"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                >
                  <i
                    className="an an-times-r"
                    aria-hidden="true"
                    data-bs-toggle="tooltip"
                    data-bs-placement="left"
                    title="Close"
                  />
                </a>
                <h4 className="fs-6">Your cart ({count} Items)</h4>
              </div>

              <div className="minicart-content">
                <ul className="clearfix">{dataHtml(data || [])}</ul>
              </div>
              <div className="minicart-bottom">
                <div className="shipinfo text-center mb-3 text-uppercase">
                  <p className="freeShipMsg">
                    <i className="an an-truck fs-5 me-2 align-middle" />
                    SPENT <b>$199.00</b> MORE FOR FREE SHIPPING
                  </p>
                </div>
                <div className="subtotal">
                  <span>Total:</span>
                  <span className="product-price">₹{total}</span>
                </div>

                <a
                  href="/checkout"
                  className="w-100 p-2 my-2 btn btn-outline-primary proceed-to-checkout rounded modalCliseLink"
                >
                  Proceed to Checkout
                </a>

                <a
                  id="modalCliseLink2"
                  href={"/cart"}
                  className="w-100 p-2 my-2 btn btn-outline-primary proceed-to-checkout rounded"
                >
                  View Cart
                </a>
              </div>
            </div>
            {/*End MiniCart Content*/}
          </div>
        </div>
      </div>
      {/*End MiniCart Drawer*/}
      <div className="modalOverly" />
      {/*Quickview Popup*/}
      <div className="loadingBox">
        <div className="an-spin">
          <i className="icon an an-spinner4" />
        </div>
      </div>
      <div id="quickView-modal" className="mfp-with-anim mfp-hide">
        <button title="Close (Esc)" type="button" className="mfp-close">
          ×
        </button>
        <div className="row">
          <div className="col-12 col-sm-6 col-md-6 col-lg-6 mb-3 mb-md-0">
            {/*Model thumbnail */}
            <div id="quickView" className="carousel slide">
              {/* Image Slide carousel items */}
              <div className="carousel-inner">
                <div
                  className="item carousel-item active"
                  data-bs-slide-number={0}
                >
                  <img
                    className="blur-up lazyload"
                    data-src="../../assets/images/products/product-5.jpg"
                    src="../../assets/images/products/product-5.jpg"
                    alt=""
                    title=""
                  />
                </div>
                <div className="item carousel-item" data-bs-slide-number={1}>
                  <img
                    className="blur-up lazyload"
                    data-src="assets/images/products/product-5-1.jpg"
                    src="assets/images/products/product-5-1.jpg"
                    alt=""
                    title=""
                  />
                </div>
                <div className="item carousel-item" data-bs-slide-number={2}>
                  <img
                    className="blur-up lazyload"
                    data-src="assets/images/products/product-5-2.jpg"
                    src="assets/images/products/product-5-2.jpg"
                    alt=""
                    title=""
                  />
                </div>
                <div className="item carousel-item" data-bs-slide-number={3}>
                  <img
                    className="blur-up lazyload"
                    data-src="assets/images/products/product-5-3.jpg"
                    src="assets/images/products/product-5-3.jpg"
                    alt=""
                    title=""
                  />
                </div>
                <div className="item carousel-item" data-bs-slide-number={4}>
                  <img
                    className="blur-up lazyload"
                    data-src="assets/images/products/product-5-4.jpg"
                    src="assets/images/products/product-5-4.jpg"
                    alt=""
                    title=""
                  />
                </div>
              </div>
              {/* End Image Slide carousel items */}
              {/* Thumbnail image */}
              <div className="model-thumbnail-img">
                {/* Thumbnail slide */}
                <div className="carousel-indicators list-inline">
                  <div
                    className="list-inline-item active"
                    id="carousel-selector-0"
                    data-bs-slide-to={0}
                    data-bs-target="#quickView"
                  >
                    <img
                      className="blur-up lazyload"
                      data-src="assets/images/products/product-5.jpg"
                      src="assets/images/products/product-5.jpg"
                      alt=""
                      title=""
                    />
                  </div>
                  <div
                    className="list-inline-item"
                    id="carousel-selector-1"
                    data-bs-slide-to={1}
                    data-bs-target="#quickView"
                  >
                    <img
                      className="blur-up lazyload"
                      data-src="assets/images/products/product-5-1.jpg"
                      src="assets/images/products/product-5-1.jpg"
                      alt=""
                      title=""
                    />
                  </div>
                  <div
                    className="list-inline-item"
                    id="carousel-selector-2"
                    data-bs-slide-to={2}
                    data-bs-target="#quickView"
                  >
                    <img
                      className="blur-up lazyload"
                      data-src="assets/images/products/product-5-2.jpg"
                      src="assets/images/products/product-5-2.jpg"
                      alt=""
                      title=""
                    />
                  </div>
                  <div
                    className="list-inline-item"
                    id="carousel-selector-3"
                    data-bs-slide-to={3}
                    data-bs-target="#quickView"
                  >
                    <img
                      className="blur-up lazyload"
                      data-src="assets/images/products/product-5-3.jpg"
                      src="assets/images/products/product-5-3.jpg"
                      alt=""
                      title=""
                    />
                  </div>
                  <div
                    className="list-inline-item"
                    id="carousel-selector-4"
                    data-bs-slide-to={4}
                    data-bs-target="#quickView"
                  >
                    <img
                      className="blur-up lazyload"
                      data-src="assets/images/products/product-5-4.jpg"
                      src="assets/images/products/product-5-4.jpg"
                      alt=""
                      title=""
                    />
                  </div>
                </div>
                {/* End Thumbnail slide */}
                {/* Carousel arrow button */}
                <a
                  className="carousel-control-prev carousel-arrow"
                  href="#quickView"
                  data-bs-target="#quickView"
                  data-bs-slide="prev"
                >
                  <i className="icon an-3x an an-angle-left" />
                  <span className="visually-hidden">Previous</span>
                </a>
                <a
                  className="carousel-control-next carousel-arrow"
                  href="#quickView"
                  data-bs-target="#quickView"
                  data-bs-slide="next"
                >
                  <i className="icon an-3x an an-angle-right" />
                  <span className="visually-hidden">Next</span>
                </a>
                {/* End Carousel arrow button */}
              </div>
              {/* End Thumbnail image */}
            </div>
            {/*End Model thumbnail */}
            <div className="text-center mt-3">
              <a href="product-layout.html">VIEW MORE DETAILS</a>
            </div>
          </div>
          <div className="col-12 col-sm-6 col-md-6 col-lg-6">
            <h2 className="product-title">Product Quick View Popup</h2>
            <div className="product-review d-flex-center mb-2">
              <div className="rating">
                <i className="icon an an-star" />
                <i className="icon an an-star" />
                <i className="icon an an-star" />
                <i className="icon an an-star" />
                <i className="icon an an-star-o" />
              </div>
              <div className="reviews ms-2">
                <a href="#!">5 Reviews</a>
              </div>
            </div>
            <div className="product-info">
              <p className="product-vendor">
                Vendor:{" "}
                <span className="fw-normal">
                  <a href="#!" className="fw-normal">
                    Optimal
                  </a>
                </span>
              </p>
              <p className="product-type">
                Product Type: <span className="fw-normal">Tops</span>
              </p>
              <p className="product-sku">
                SKU: <span className="fw-normal">50-ABC</span>
              </p>
            </div>
            <div className="pro-stockLbl my-2">
              <span className="d-flex-center stockLbl instock">
                <i className="icon an an-check-cil" />
                <span> In stock</span>
              </span>
              <span className="d-flex-center stockLbl preorder d-none">
                <i className="icon an an-clock-r" />
                <span> Pre-order Now</span>
              </span>
              <span className="d-flex-center stockLbl outstock d-none">
                <i className="icon an an-times-cil" /> <span>Sold out</span>
              </span>
              <span
                className="d-flex-center stockLbl lowstock d-none"
                data-qty={15}
              >
                <i className="icon an an-exclamation-cir" />
                <span>
                  {" "}
                  Order now, Only <span className="items">10</span>
                  left!
                </span>
              </span>
            </div>
            <div className="pricebox">
              <span className="price old-price">$400.00</span>
              <span className="price product-price__sale">$300.00</span>
            </div>
            <div className="sort-description">
              Optimal Multipurpose Bootstrap 5 Html Template that will give you
              and your customers a smooth shopping experience which can be used
              for various kinds of stores such as fashion..
            </div>
            <form
              method="post"
              action="#"
              id="product_form--option"
              className="product-form"
            >
              <div className="product-options d-flex-wrap">
                <div className="swatch clearfix swatch-0 option1">
                  <div className="product-form__item">
                    <label className="label d-flex">
                      Color:<span className="required d-none">*</span>{" "}
                      <span className="slVariant ms-1 fw-bold">Black</span>
                    </label>
                    <ul className="swatches-image swatches d-flex-wrap list-unstyled clearfix">
                      <li
                        data-value="Black"
                        className="swatch-element color available active"
                      >
                        <label
                          className="rounded swatchLbl small color black"
                          title="Black"
                        />
                        <span className="tooltip-label top">Black</span>
                      </li>
                      <li
                        data-value="Green"
                        className="swatch-element color available"
                      >
                        <label
                          className="rounded swatchLbl small color green"
                          title="Green"
                        />
                        <span className="tooltip-label top">Green</span>
                      </li>
                      <li
                        data-value="Orange"
                        className="swatch-element color available"
                      >
                        <label
                          className="rounded swatchLbl small color orange"
                          title="Orange"
                        />
                        <span className="tooltip-label top">Orange</span>
                      </li>
                      <li
                        data-value="Blue"
                        className="swatch-element color available"
                      >
                        <label
                          className="rounded swatchLbl small color blue"
                          title="Blue"
                        />
                        <span className="tooltip-label top">Blue</span>
                      </li>
                      <li
                        data-value="Red"
                        className="swatch-element color available"
                      >
                        <label
                          className="rounded swatchLbl small color red"
                          title="Red"
                        />
                        <span className="tooltip-label top">Red</span>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="swatch clearfix swatch-1 option2">
                  <div className="product-form__item">
                    <label className="label">
                      Size:<span className="required d-none">*</span>{" "}
                      <span className="slVariant ms-1 fw-bold">XS</span>
                    </label>
                    <ul className="swatches-size d-flex-center list-unstyled clearfix swatch-1 option2">
                      <li
                        data-value="XS"
                        className="swatch-element xs available active"
                      >
                        <label className="swatchLbl rounded medium" title="XS">
                          XS
                        </label>
                        <span className="tooltip-label">XS</span>
                      </li>
                      <li data-value="S" className="swatch-element s available">
                        <label className="swatchLbl rounded medium" title="S">
                          S
                        </label>
                        <span className="tooltip-label">S</span>
                      </li>
                      <li data-value="M" className="swatch-element m available">
                        <label className="swatchLbl rounded medium" title="M">
                          M
                        </label>
                        <span className="tooltip-label">M</span>
                      </li>
                      <li data-value="L" className="swatch-element l available">
                        <label className="swatchLbl rounded medium" title="L">
                          L
                        </label>
                        <span className="tooltip-label">L</span>
                      </li>
                      <li
                        data-value="XL"
                        className="swatch-element xl available"
                      >
                        <label className="swatchLbl rounded medium" title="XL">
                          XL
                        </label>
                        <span className="tooltip-label">XL</span>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="product-action d-flex-wrap w-100 mb-3 clearfix">
                  <div className="quantity">
                    <div className="qtyField rounded">
                      <a className="qtyBtn minus" href="#!">
                        <i className="icon an an-minus-r" aria-hidden="true" />
                      </a>
                      <input
                        type="text"
                        name="quantity"
                        defaultValue={1}
                        className="product-form__input qty"
                      />
                      <a className="qtyBtn plus" href="#!">
                        <i className="icon an an-plus-l" aria-hidden="true" />
                      </a>
                    </div>
                  </div>
                  <div className="add-to-cart ms-3 fl-1">
                    <button type="button" className="btn button-cart rounded">
                      <span>Add to cart</span>
                    </button>
                  </div>
                </div>
              </div>
            </form>
            <div className="wishlist-btn d-flex-center">
              <a
                className="add-wishlist d-flex-center text-uppercase me-3"
                href="my-wishlist.html"
                title="Add to Wishlist"
              >
                <i className="icon an an-heart-l me-1" />{" "}
                <span>Add to Wishlist</span>
              </a>
              <a
                className="add-compare d-flex-center text-uppercase"
                href="compare-style1.html"
                title="Add to Compare"
              >
                <i className="icon an an-random-r me-2" />{" "}
                <span>Add to Compare</span>
              </a>
            </div>
            {/* Social Sharing */}
            <div className="social-sharing share-icon d-flex-center mx-0 mt-3">
              <span className="sharing-lbl me-2">Share :</span>
              <a
                href="#!"
                className="d-flex-center btn btn-link btn--share share-facebook"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Share on Facebook"
              >
                <i className="icon an an-facebook mx-1" />
                <span className="share-title d-none">Facebook</span>
              </a>
              <a
                href="#!"
                className="d-flex-center btn btn-link btn--share share-twitter"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Tweet on Twitter"
              >
                <i className="icon an an-twitter mx-1" />
                <span className="share-title d-none">Tweet</span>
              </a>
              <a
                href="#!"
                className="d-flex-center btn btn-link btn--share share-pinterest"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Pin on Pinterest"
              >
                <i className="icon an an-pinterest-p mx-1" />{" "}
                <span className="share-title d-none">Pin it</span>
              </a>
              <a
                href="#!"
                className="d-flex-center btn btn-link btn--share share-linkedin"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Share on Instagram"
              >
                <i className="icon an an-instagram mx-1" />
                <span className="share-title d-none">Instagram</span>
              </a>
              <a
                href="#!"
                className="d-flex-center btn btn-link btn--share share-whatsapp"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Share on WhatsApp"
              >
                <i className="icon an an-whatsapp mx-1" />
                <span className="share-title d-none">WhatsApp</span>
              </a>
              <a
                href="#!"
                className="d-flex-center btn btn-link btn--share share-email"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Share by Email"
              >
                <i className="icon an an-envelope-l mx-1" />
                <span className="share-title d-none">Email</span>
              </a>
            </div>
            {/* End Social Sharing */}
          </div>
          <Toaster />
        </div>
      </div>
    </>
  );
}
export default Footer;

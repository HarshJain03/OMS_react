import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Toaster, toast } from "react-hot-toast";
import "react-toastify/dist/ReactToastify.css";
import SliderS from "./Slider";
import Header from "./Header";
import Footer from "./Footer";
import * as myConstList from "./BaseUrl";
const baseUrl = myConstList.baseUrl;

function Index() {
  const [data, setData] = useState([]);
  const [data2, setData2] = useState([]);
  const [userD, setUser] = useState([]);
  const [categoryId, setCategoryId] = useState("");

  const [refreshed, setRefreshed] = useState(new Date().getTime());

  useEffect(() => {
    getUserData();
  }, [refreshed]);

  const getUserData = () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    axios.post(baseUrl + "/frontapi/get-user-data", {}, config).then((res) => {
      var resp = res.data;
      if (resp.status === false) {
        if (resp.message == "Failed to authenticate token.") {
          setTimeout(() => {
            localStorage.clear();
            window.location.href = "/";
          }, 2000);
        }
        toast.dismiss();
        toast.error(resp.message);
        return;
      }
      if (resp.status == true) {
        productData(resp.data[0].categoryId);
        setCategoryId(resp.data[0].categoryId);
        setUser(resp.data);
      }
    });
  };

  const productData = (value) => {
    // let params = {
    //   categoryId: value,
    // };
    axios.post(baseUrl + "/frontapi/product-data", {}).then((res) => {
      var resp = res.data;
      if (resp.status === false) {
        toast.dismiss();
        toast.error(resp.message);
        return;
      }
      if (resp.status === true) {
        setData(resp.data);
      }
    });
  };

  const addToCart = async (value) => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    let params = {
      productId: value,
      qty: 1,
    };
    await axios
      .post(baseUrl + "/frontapi/add-cart", params, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === false) {
          toast.dismiss();
          toast.error(resp.message);
          return;
        }
        if (resp.status === true) {
          toast.success(resp.message);
          setData2(resp.data);
          setRefreshed(true);
        }
      });
  };

  const productDataHtml = () => {
    const html = [];
    data.map(function (value, i) {
      var pimages = value.image ? value.image.split(",") : "";
      console.log("first", pimages);
      return html.push(
        <div className="item col-lg-3 col-md-4 col-6">
          <div className="product-image">
            <Link className="product-img" to={"/product-detail/" + value.id}>
              <img
                className="primary blur-up lazyload"
                data-src={baseUrl + "/static" + pimages[0]}
                src={baseUrl + "/static" + pimages[0]}
                alt=""
                title=""
                width={800}
                height={960}
              />
              <img
                className="hover blur-up lazyload"
                data-src={baseUrl + "/static" + pimages[1]}
                src={baseUrl + "/" + pimages[1]}
                alt=""
                title=""
                width={800}
                height={960}
              />
            </Link>
            {localStorage.getItem("userType") === "customer" && (
              <div className="button-set-bottom position-absolute style1">
                <button
                  type="button"
                  onClick={() => addToCart(value.id)}
                  className="btn-icon btn btn-addto-cart pro-addtocart-popup rounded"
                >
                  <i className="icon an an-cart-l" /> <span>Add To Cart</span>
                </button>
              </div>
            )}
          </div>

          <div className="product-details text-center">
            <div className="product-name text-uppercase">
              <a href={"/product-detail/" + value.id}> {value.name} </a>
            </div>
            <div className="product-price">
              <span className="price">
                {" "}
                Suggested Price ₹
                {value.sale_price + (value.sale_price * value.tax) / 100}{" "}
                (including GST)
              </span>
            </div>
          </div>
        </div>
      );
    });
    return html;
  };

  return (
    <>
      <Header refreshed={refreshed} setRefreshed={setRefreshed} />
      <div id="page-content">
        <SliderS />
        <section className="section product-slider">
          <div className="container">
            <div className="row">
              <div className="col-12 section-header style1">
                <div className="section-header-left">
                  <h2>BEST SELLER</h2>
                  <p>TOP SALE IN THIS WEEK</p>
                </div>
              </div>
            </div>
            <div className="grid-products">
              <div className="row">{productDataHtml()}</div>
            </div>
          </div>
        </section>
        <Footer refreshed={refreshed} setRefreshed={setRefreshed} />
        <Toaster />
      </div>
    </>
  );
}
export default Index;

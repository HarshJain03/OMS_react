import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "./Header";
import Footer from "./Footer";
import moment from "moment";
import * as myConstList from "./BaseUrl";
const baseUrl = myConstList.baseUrl;

function CheckoutSuccess() {
  const [orderId, setOrderId] = useState("");
  const [date, setDate] = useState("");

  //
  useEffect(() => {
    orders();
  }, []);

  const orders = async () => {
    // alert('dataaaa');
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios.post(baseUrl + "/frontapi/orders", {}, config).then((res) => {
      var resp = res.data;
      if (resp.status) {
        setOrderId(resp.data[0].orderId);
        setDate(resp.data[0].createdAt);
      } else {
        toast.dismiss();
        toast.error(resp.message);
      }
    });
  };
  return (
    <>
      <Header />
      <div id="page-content">
        {/* <SliderS/> */}
        <>
          <div id="page-content">
            {/*Collection Banner*/}
            <div className="collection-header">
              <div className="collection-hero">
                <div className="collection-hero__image" />
                <div className="collection-hero__title-wrapper container">
                  <h1 className="collection-hero__title">Checkout Success</h1>
                  <div className="breadcrumbs text-uppercase mt-1 mt-lg-2">
                    <a href="index.html" title="Back to the home page">
                      Home
                    </a>
                    <span>|</span>
                    <span className="fw-bold">Checkout Success</span>
                  </div>
                </div>
              </div>
            </div>
            {/*End Collection Banner*/}
            {/*Main Content*/}
            <div className="container">
              <div className="checkout-success-content py-2">
                {/*Order Card*/}
                <div className="row">
                  <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                    <div className="checkout-scard card border-0 rounded">
                      <div className="card-body text-center">
                        <p className="card-icon">
                          <i className="icon an an-shield-check fs-1" />
                        </p>
                        <h4 className="card-title">
                          Thank you for your order!
                        </h4>
                        <p className="card-text mb-1">
                          You will receive an order confirmation email with
                          details of your order and a link to track its
                          progress.
                        </p>
                        <p className="card-text mb-1">
                          All necessary information about the delivery, we sent
                          to your email
                        </p>
                        <p className="card-text text-order badge bg-success my-3">
                          Your order # is: <b>0000{orderId}</b>
                        </p>
                        <p className="card-text mb-0">
                          Order date: {moment(date).format("lll")}{" "}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                {/*End Order Card*/}
              </div>
            </div>
            {/*End Main Content*/}
          </div>
        </>
        <Footer />
      </div>
    </>
  );
}
export default CheckoutSuccess;

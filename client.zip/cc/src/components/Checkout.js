import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Toaster, toast } from "react-hot-toast";
import "react-toastify/dist/ReactToastify.css";
import Header from "./Header";
import Footer from "./Footer";
import * as myConstList from "./BaseUrl";
import { Modal } from "react-bootstrap";
// import { Document, Page, pdfjs } from "react-pdf";

const baseUrl = myConstList.baseUrl;

function Checkout(props) {
  // pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
  const [data, setData] = useState([]);
  const [cutomizeOption, setCutomizeOption] = useState("no");
  const [inputPrice, setInputPrice] = useState("");
  const [showEditModal, setShowEditModal] = useState(false);
  const [productName, setProductName] = useState("");
  const [productImage, setProductImage] = useState("");
  const [productId, setProductId] = useState("");
  const [customizeImage, setCustomizeImage] = useState("");
  const [customizeName, setCustomizeName] = useState("");
  const [showViewModal, setShowViewModal] = useState(false);
  const [refreshed, setRefreshed] = useState(new Date().getTime());
  // const [pageNumber, setPageNumber] = useState(1)

  useEffect(() => {
    getCartDataByUserId();
    if (localStorage.getItem("userType") !== "customer") {
      window.location.href = "/dashboard";
    }
  }, [refreshed]);

  const getCartDataByUserId = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios
      .post(baseUrl + "/frontapi/getCartDataByUserId", {}, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          setRefreshed(true);
          setData(resp.data);
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const handleChange = (e) => {
    if (e.target.name === "customize") {
      let eventValue = e.target.value;
      setCutomizeOption(eventValue);
    }
    if (e.target.name === "product_price") {
      setInputPrice(e.target.value);
    }
    if (e.target.name === "customize_image") {
      var customizeImage = e.target.files[0];
      var fileSize = e.target.files[0].size;
      if (fileSize > 1000000) {
        toast.error("Maximum 1 MB Image allowed");
        return false;
      }
      if (!customizeImage.name.match(/\.(jpg|jpeg|png|gif|pdf|doc)$/)) {
        toast.error("Please select valid image jpeg,png,gif.");
        return false;
      }
      setCustomizeName(e.target.files[0].name);
      setCustomizeImage(customizeImage);
    }
  };

  const closeShowEditModel = () => {
    setShowEditModal(false);
    setShowViewModal(false);
    setCutomizeOption("no");
  };

  let grantTotalAmount = 0;
  let productIdArr = [];
  let priceArr = [];
  let taxPriceArr = [];
  let subtotalArr = [];
  let quantityArr = [];
  let gstArr = [];
  const dataTr = () => {
    let html = [];
    data.map((value, i) => {
      productIdArr.push(value.id);
      quantityArr.push(value.product_qty);
      let price = value.product_amount * value.product_qty;
      priceArr.push(price);
      gstArr.push(value.product_gst_percent);
      let taxPrice = (price / 100) * value.product_gst_percent;
      taxPriceArr.push(taxPrice);
      let subtotal = taxPrice + price;
      subtotalArr.push(subtotal);
      grantTotalAmount = grantTotalAmount + subtotal;
      return html.push(
        <tr>
          <td className="thumbImg">
            <Link
              to={"/product-detail/" + value.product_id}
              className="thumb d-inline-block"
            >
              <img
                className="cart__image"
                src={baseUrl + "/static" + value.product_image}
                alt="Sunset Sleep Scarf Top"
                width={80}
              />
            </Link>
          </td>
          <td className="text-start">
            <Link to={"/product-detail/" + value.product_id}>
              {" "}
              {value.product_name}{" "}
            </Link>
            <div className="cart__meta-text">
              {value.product_attrbitute_name +
                ":" +
                value.product_attrbitute_value}
            </div>
          </td>
          <td> {"₹" + price} </td>
          <td> {value.product_qty}</td>
          <td> {value.product_gst_percent + "%"} </td>
          <td> {taxPrice} </td>
          <td className="fw-500">₹{subtotal}</td>
          {localStorage.userType == "SalesPerson" && (
            <td className="fw-500" onClick={() => getEditDetails(data[i])}>
              {value.isCustomize == "N" ? (
                <a href="#!" className="btn btn-primary">
                  Edit
                </a>
              ) : (
                <a href="#!" className="btn btn-primary">
                  View
                </a>
              )}
            </td>
          )}
        </tr>
      );
    });
    return html;
  };

  const getEditDetails = (data) => {
    console.log(data.isCustomize);
    if (data.isCustomize == "N") {
      setShowEditModal(true);
    }
    if (data.isCustomize == "Y") {
      setShowViewModal(true);
      setCustomizeName(data.customize_image);
    }
    setProductName(data.product_name);
    setInputPrice(data.product_amount);
    setProductId(data.id);
    setProductImage(data.product_image);
  };

  const submitData = async () => {
    let params = {
      product_Id: productIdArr,
      price: priceArr,
      quantity: quantityArr,
      gst: gstArr,
      taxPrice: taxPriceArr,
      subtotal: subtotalArr,
      total: grantTotalAmount,
    };
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios
      .post(baseUrl + "/frontapi/placeOrder", params, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          toast.success("Order placed  successfully");
          setTimeout(
            function () {
              window.location = "/checkout-success";
            }.bind(this),
            3000
          );
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
    return;
  };

  const updateCustomerData = () => {
    const config = {
      headers: {
          
        Authorization: `Bearer ${localStorage.getItem("jwtToken")}`,
      },
    };
    const formData = new FormData();
    formData.append("product_id", productId);
    formData.append("amount", inputPrice);
    formData.append("customizeImage", customizeImage);

    axios
      .post(baseUrl + "/frontapi/updateOrderPrice", formData, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === true) {
          toast.success(resp.message);
          setShowEditModal(false);
          setShowViewModal(false);
          setCutomizeOption("");
          setCustomizeImage("");
          setInputPrice("");
          getCartDataByUserId();
        } else {
          toast.error(resp.message);
        }
      });
  };

  return (
    <>
      <Header />
      <div id="page-content">
        <>
          <div className="collection-header">
            <div className="collection-hero">
              <div className="collection-hero__image" />
              <div className="collection-hero__title-wrapper container">
                <h1 className="collection-hero__title">Checkout</h1>
                <div className="breadcrumbs text-uppercase mt-1 mt-lg-2">
                  <Link to={"/dashboard"}>Home</Link>
                  <span>|</span>
                  <span className="fw-bold">Checkout</span>
                </div>
              </div>
            </div>
          </div>
          <div className="container">
            <div className="row">
              <div className="col-12">
                <h2 className="title fs-6">ORDER SUMMARY</h2>
                <div className="table-responsive order-table style1">
                  <table className="table table-bordered align-middle table-hover text-center mb-1">
                    <thead>
                      <tr>
                        <th>Product</th>
                        <th className="text-start">Name</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>GST(%)</th>
                        <th>GST(Amount)</th>
                        <th>Subtotal</th>
                        {localStorage.userType == "SalesPerson" && (
                          <th>Customize</th>
                        )}
                      </tr>
                    </thead>
                    <tbody>{dataTr()}</tbody>
                    <tfoot className="font-weight-600">
                      <tr>
                        <td colSpan={6} className="text-end fw-bolder">
                          Total
                        </td>
                        <td className="fw-bolder">₹ {grantTotalAmount}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
                {data.length > 0 ? (
                  <div className="order-button-payment mt-2 clearfix">
                    {localStorage.userType == "SalesPerson" ? (
                      <a
                        href="/select-customer"
                        className="cartCheckout fs-6 btn btn-lg rounded w-100 fw-600 text-white"
                      >
                        Continue
                      </a>
                    ) : (
                      <button
                        onClick={submitData}
                        className="cartCheckout fs-6 btn btn-lg rounded w-100 fw-600 text-white"
                      >
                        Place order
                      </button>
                    )}
                  </div>
                ) : (
                  <a
                    className="cartCheckout fs-6 btn btn-lg rounded w-100 fw-600 text-white"
                    href="/dashboard"
                  >
                    Please add product
                  </a>
                )}
              </div>
            </div>
          </div>
          <Modal
            className="modal-update"
            show={showEditModal}
            onHide={closeShowEditModel}
          >
            <Modal.Header closeButton>
              <Modal.Title className="m-0"> Update</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="row">
                <div className="col-12">
                  <div className="product-name-img form-group">
                    <label>Product : {productName}</label>
                    <img
                      className="cart__image"
                      src={baseUrl + "/static" + productImage}
                      alt="Sunset Sleep Scarf Top"
                      width={80}
                    />
                  </div>
                </div>
                {cutomizeOption == "yes" ? (
                  <div className="col-md-6 col-12">
                    <div className="product-price d-flex flex-wrap align-items-center form-group">
                      <label>Price :</label>
                      <input
                        type={"number"}
                        name="product_price"
                        value={inputPrice}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                ) : (
                  ""
                )}
                <div className="col-md-6 col-12">
                  <div className="yes-no-outer form-group d-flex flex-wrap">
                    {cutomizeOption == "yes" ? (
                      <div className="upload-file position-relative">
                        <label for="staticEmail2" className="file-upload-label">
                          File Upload
                        </label>
                        <input
                          type="file"
                          name="customize_image"
                          onChange={handleChange}
                        />
                        <span>{customizeName}</span>
                      </div>
                    ) : (
                      <>
                        <label className="m-0">File Upload : </label>
                        <div class="form-check form-check-inline checkbox-main-outer d-flex flex-wrap align-items-center">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="customize"
                            id="inlineRadio1"
                            value={"yes"}
                            onChange={(e) => handleChange(e)}
                          />
                          <label
                            className="form-check-label"
                            for="inlineRadio1"
                          >
                            Yes
                          </label>
                        </div>
                        <div className="form-check form-check-inline checkbox-main-outer d-flex flex-wrap align-items-center">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="customize"
                            id="inlineRadio2"
                            value={"no"}
                            onChange={(e) => handleChange(e)}
                          />
                          <label
                            className="form-check-label"
                            for="inlineRadio2"
                          >
                            No
                          </label>
                        </div>
                      </>
                    )}
                  </div>
                </div>
                <div className="col-12">
                  <div className="submit-btn">
                    <button
                      className="cartCheckout fs-6 btn btn-lg rounded w-100 fw-600 text-white"
                      onClick={updateCustomerData}
                    >
                      Update
                    </button>
                  </div>
                </div>
              </div>
            </Modal.Body>
          </Modal>
          <Modal
            className="modal-update"
            show={showViewModal}
            onHide={closeShowEditModel}
          >
            <Modal.Header closeButton>
              <Modal.Title className="m-0"> View</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="row">
                <div className="col-12">
                  <div className="product-name-img form-group">
                    <label>Product : {productName}</label>
                    <img
                      className="cart__image"
                      src={baseUrl + "/static" + productImage}
                      alt="Sunset Sleep Scarf Top"
                      width={80}
                    />
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <div className="product-price d-flex flex-wrap align-items-center form-group">
                    <label>Price :</label>
                    <input
                      type={"number"}
                      name="product_price"
                      value={inputPrice}
                      onChange={handleChange}
                      disabled
                    />
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <div className="yes-no-outer form-group d-flex flex-wrap">
                    <div className="upload-file position-relative">
                      {/* <Document
                        file={
                          baseUrl + "/static/customizeImage/" + customizeName
                        }
                        noData={<h4>Please select a file</h4>}
                      >
                        <Page pageNumber={pageNumber} />
                      </Document> */}

                      <span>{customizeName}</span>
                    </div>
                  </div>
                </div>
              </div>
            </Modal.Body>
          </Modal>
        </>

        <Footer refreshed={refreshed} setRefreshed={setRefreshed} />
        <Toaster />
      </div>
    </>
  );
}
export default Checkout;

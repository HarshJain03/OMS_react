import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import * as myConstList from "./BaseUrl";
import { Modal } from "react-bootstrap";
const baseUrl = myConstList.baseUrl;

function Header(props) {
  const [count, setCount] = useState("");
  const [show, setShow] = useState(false);
  const [show2, setShow2] = useState(false);
  const [showProductsModal, setShowProductsModal] = useState(false);
  const [data, setData] = useState([]);
  const [cutomizeOption, setCutomizeOption] = useState("");

  useEffect(() => {
    productCout();
    getUserData();
  }, [props]);

  const getUserData = () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    axios.post(baseUrl + "/frontapi/get-user-data", {}, config).then((res) => {
      var resp = res.data;
      if (resp.status === false) {
        if (resp.message == "Failed to authenticate token.") {
          setTimeout(() => {
            localStorage.clear();
            window.location.href = "/";
          }, 2000);
        }
        toast.dismiss();
        toast.error(resp.message);
        return;
      }
      if (resp.status == true) {
        productData(resp.data[0].categoryId);
      }
    });
  };

  const productData = (value) => {
    let params = {
      categoryId: value,
    };
    axios.post(baseUrl + "/frontapi/product-data", params).then((res) => {
      var resp = res.data;
      if (resp.status === false) {
        toast.dismiss();
        toast.error(resp.message);
        return;
      }
      if (resp.status === true) {
        setData(resp.data);
      }
    });
  };

  const productCout = () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    axios.post(baseUrl + "/frontapi/product-count", {}, config).then((res) => {
      var resp = res.data;
      if (resp.status === false) {
        toast.dismiss();
        toast.error(resp.message);
        return;
      }
      if (resp.status === true) {
        setCount(resp.data.length);
      }
    });
  };
  const logout = async () => {
    localStorage.clear();
    window.location.href = "/";
  };

  const addProducts = () => {
    setShowProductsModal(true);
  };
  const closeProductsModal = () => {
    showProductsModal(false);
    setCutomizeOption("no");
  };
  const handleChange = (e) => {
    if (e.target.name === "customize") {
      let eventValue = e.target.value;
      setCutomizeOption(eventValue);
    }
  };

  return (
    <div id="header" className="header header-1">
      <div className="header-main">
        <header className="header-wrap container d-flex align-items-center">
          <div className="row g-0 align-items-center w-100">
            <div className="col-4 col-sm-4 col-md-4 col-lg-5 d-none d-lg-block">
              <ul className="social-icons list-inline">
                <li className="list-inline-item">
                  <a href="#!">
                    <i className="an an-facebook" aria-hidden="true" />
                    <span className="tooltip-label">Facebook</span>
                  </a>
                </li>
                <li className="list-inline-item">
                  <a href="#!">
                    <i className="an an-twitter" aria-hidden="true" />
                    <span className="tooltip-label">Twitter</span>
                  </a>
                </li>
                <li className="list-inline-item">
                  <a href="#!">
                    <i className="an an-instagram" aria-hidden="true" />
                    <span className="tooltip-label">Instagram</span>
                  </a>
                </li>
              </ul>
            </div>
            <div className="col-6 col-sm-6 col-md-6 col-lg-2 d-flex">
              {/*Logo*/}
              <div className="logo mx-lg-auto">
                <Link to={"/dashboard"}>
                  <img
                    className="logo-img"
                    src="assets/images/logo.png"
                    alt=""
                  />
                </Link>
              </div>
            </div>
            <div className="col-6 col-sm-6 col-md-6 col-lg-5 icons-col text-right d-flex justify-content-end">
              <div
                className="site-search iconset"
                onClick={() => setShow2((prev) => !prev)}
              >
                <i className="icon an an-search-l" />
                <span className="tooltip-label">Search</span>
              </div>
              <div
                className="user-link iconset"
                onClick={() => setShow((prev) => !prev)}
              >
                <i className="icon an an-user-expand" />
                <span className="tooltip-label">Account</span>
              </div>
              {show && (
                <div id="userLinks" className="active">
                  <ul className="user-links">
                    <li>
                      <Link to={"/dashboard"}> Our Products </Link>
                    </li>
                    <li>
                      <Link to={"/active-orders"}> Active Orders </Link>
                    </li>
                    <li>
                      <Link to={"/order-history"}> Order History </Link>
                    </li>
                    <li>
                      <Link to="#" onClick={logout}>
                        {" "}
                        Log out{" "}
                      </Link>
                    </li>
                  </ul>
                </div>
              )}
              {show2 && (
                <div id="search-popup" className="search-drawer active">
                  <div className="container">
                    <span className="closeSearch an an-times-l" />
                    <form
                      className="form minisearch"
                      id="header-search"
                      action="#"
                      method="get"
                    >
                      <label className="label">
                        <span>Search</span>
                      </label>
                      <div className="control">
                        <div className="searchField">
                          <div className="input-box">
                            <button
                              type="submit"
                              title="Search"
                              className="action search"
                              disabled=""
                            >
                              <i className="icon an an-search-l" />
                            </button>
                            <input
                              type="text"
                              name="q"
                              defaultValue=""
                              placeholder="Search by keyword or #"
                              className="input-text"
                            />
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              )}
              <div className="header-cart iconset">
                {localStorage.getItem("userType") === "customer" ? (
                  <a
                    href="#!"
                    className="site-header__cart btn-minicart"
                    data-bs-toggle="modal"
                    data-bs-target="#minicart-drawer"
                  >
                    <i className="icon an an-sq-bag" />
                    <span className="site-cart-count counter d-flex-center justify-content-center position-absolute translate-middle rounded-circle">
                      {count}
                    </span>
                    <span className="tooltip-label">Cart</span>
                  </a>
                ) : (
                  <div className="add-row-group">
                    <div className="add-row btn-group  m-0">
                      <a
                        className="btn btn-primary remove"
                        href="/product-form"
                      >
                        +
                      </a>
                    </div>
                    <span className="tooltip-label">Add Products</span>
                  </div>
                )}
              </div>
            </div>
          </div>
          <Modal
            className="modal-update"
            show={showProductsModal}
            onHide={closeProductsModal}
          >
            <Modal.Header closeButton>
              <Modal.Title className="m-0">Add Order</Modal.Title>
            </Modal.Header>
            <Modal.Body className="assign-vendor">
              <div className="row">
                <div className="col-md-6 col-12">
                  <div className="product-price form-group">
                    <lable>Product Name</lable>
                    <select className="form-control">
                      <option>Select Product</option>

                      {data.map((item, i) => {
                        return <option key={item.name} value={item.id}>{item.name}</option>;
                      })}
                    </select>
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <div className="product-price form-group">
                    <lable>Product Price</lable>
                    <input type={"text"} className="form-control" />
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <div className="product-price form-group">
                    <lable>Product Quantity</lable>
                    <input type={"text"} className="form-control" />
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <div className="product-price form-group">
                    <lable>Product GST</lable>
                    <input type={"text"} className="form-control" />
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <div className="yes-no-outer form-group d-flex flex-wrap">
                    {cutomizeOption == "yes" ? (
                      <div className="upload-file position-relative">
                        <label for="staticEmail2" className="file-upload-label">
                          File Upload
                        </label>
                        <input
                          type="file"
                          name="customize_image"
                          onChange={handleChange}
                        />
                      </div>
                    ) : (
                      <>
                        <label className="m-0">File Upload : </label>
                        <div class="form-check form-check-inline checkbox-main-outer d-flex flex-wrap align-items-center">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="customize"
                            id="inlineRadio1"
                            value={"yes"}
                            onChange={(e) => handleChange(e)}
                          />
                          <label
                            className="form-check-label m-0"
                            for="inlineRadio1"
                          >
                            Yes
                          </label>
                        </div>
                        <div className="form-check form-check-inline checkbox-main-outer d-flex flex-wrap align-items-center">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="customize"
                            id="inlineRadio2"
                            value={"no"}
                            onChange={(e) => handleChange(e)}
                          />
                          <label
                            className="form-check-label m-0"
                            for="inlineRadio2"
                          >
                            No
                          </label>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                <div className="col-md-6 col-12">
                  <div className="product-price">
                    <label>Total:</label>
                    <h5 className="m-0 text-black"></h5>
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <div className="product-price d-flex flex-wrap align-items-center form-group">
                    <button className="btn btn-primary">Placeholder</button>
                  </div>
                </div>
              </div>
            </Modal.Body>
          </Modal>
        </header>
      </div>
    </div>
  );
}
export default Header;

import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import { baseUrl } from "./BaseUrl";
import Footer from "./Footer";
import Header from "./Header";
import { Modal } from "react-bootstrap";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";

const SalsePersonProductForm = () => {
  const [showEditModal, setShowEditModal] = useState(false);

  const [cutomizeOption, setCutomizeOption] = useState("no");
  const [productQuantity, setProductQuantity] = useState("");
  const [tableData, setTableData] = useState([]);
  const [data, setData] = useState([]);
  const [customizeName, setCustomizeName] = useState("");
  const [customizeImage, setCustomizeImage] = useState("");
  const [productId, setProductId] = useState("");
  const [productPrice, setProductPrice] = useState("");

  const [salesPrice, setSalesPrice] = useState("");
  const [productGST, setProductGST] = useState("");
  const [salesTotal, setSalesTotal] = useState(0);
  const [productTotal, setProductTotal] = useState(0);
  const [avaliableQty, setAvaliableQty] = useState("");

  useEffect(() => {
    getUserData();
    getCartDataByUserId();
  }, []);

  const getUserData = () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    axios.post(baseUrl + "/frontapi/get-user-data", {}, config).then((res) => {
      var resp = res.data;
      if (resp.status === false) {
        if (resp.message === "Failed to authenticate token.") {
          setTimeout(() => {
            localStorage.clear();
            window.location.href = "/";
          }, 2000);
        }
        toast.dismiss();
        toast.error(resp.message);
        return;
      }
      if (resp.status === true) {
        productData(resp.data[0].categoryId);
      }
    });
  };

  const getCartDataByUserId = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios
      .post(baseUrl + "/frontapi/getCartDataByUserId", {}, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          setTableData(resp.data);
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const productData = (value) => {
    // let params = {
    //   categoryId: value,
    // };
    axios.post(baseUrl + "/frontapi/product-data", {}).then((res) => {
      var resp = res.data;
      if (resp.status === false) {
        toast.dismiss();
        toast.error(resp.message);
        return;
      }
      if (resp.status === true) {
        setData(resp.data);
      }
    });
  };

  const subTotalHtml = () => {
    let finalTotal = 0;
    tableData.map((element, index) => {
      let price = element.product_amount * element.product_qty;
      let taxPrice = (price / 100) * element.product_gst_percent;
      let subTotal = parseFloat(taxPrice) + parseFloat(price);
      finalTotal += subTotal;
    });
    return finalTotal;
  };

  const dataTr = () => {
    const html = [];
    let t = 0;
    tableData.map((element, index) => {
      let price = element.product_amount * element.product_qty;
      let taxPrice = (price / 100) * element.product_gst_percent;
      let subTotal = parseFloat(taxPrice) + parseFloat(price);
      return html.push(
        <tr
          className="cart__row border-bottom line1 cart-flex border-top"
          key={element.id}
        >
          <td className="cart__price-wrapper cart-flex-item text-center small--hide">
            {element.product_name}
          </td>
          <td className="cart__price-wrapper cart-flex-item text-center small--hide">
            {element.product_amount}
          </td>
          <td className="cart__price-wrapper cart-flex-item text-center small--hide">
            {element.product_qty}
          </td>
          <td className="cart__price-wrapper cart-flex-item text-center small--hide">
            {element.product_gst_percent}
            {"%"}
          </td>
          <td className="cart__price-wrapper cart-flex-item text-center small--hide">
            {subTotal}
          </td>
          <td className="cart__price-wrapper cart-flex-item text-center small--hide">
            {element.isCustomize}
          </td>

          <td>
            <a href="#" onClick={() => Conn(element.cart_id)}>
              <img
                src="assets/images/delete-icon.png"
                style={{ backgroundColor: "black" }}
                alt=""
                className="img-fluid"
              />
            </a>
          </td>
        </tr>
      );
    });
    return html;
  };

  const getProductDetails = (id) => {
    let data = {
      id: id,
    };
    axios.post(baseUrl + "/frontapi/product-single", data).then((res) => {
      var resp = res.data;
      if (resp.status === true) {
        setProductPrice(resp.data.sqlRun[0] ? resp.data.sqlRun[0].price : "");
        setSalesPrice(
          resp.data.sqlRun[0] ? resp.data.sqlRun[0].sale_price : ""
        );
        setProductGST(resp.data.sqlRun[0] ? resp.data.sqlRun[0].tax : "");
        setAvaliableQty(
          resp.data.sqlRun[0] ? resp.data.sqlRun[0].avaliable_qty : ""
        );
      }
    });
  };

  const handleChange = (e) => {
    if (e.target.name === "productId") {
      setProductId(e.target.value);
      getProductDetails(e.target.value);
    }
    if (e.target.name === "productQuantity") {
      setProductQuantity(e.target.value);
      let price = salesPrice * e.target.value;
      let taxPrice = (price / 100) * productGST;
      let subtotal = taxPrice + price;
      setProductTotal(subtotal);
      // For Product Price Reference
      let totalProductPrice = productPrice * e.target.value;
      let taxProductPrice = (totalProductPrice / 100) * productGST;
      let subTotalProduct = taxProductPrice + totalProductPrice;
      setSalesTotal(subTotalProduct);
    }
    if (e.target.name === "productPrice") {
      setProductPrice(e.target.value);
    }
    if (e.target.name === "salesPrice") {
      setSalesPrice(e.target.value);
      let price = productQuantity * e.target.value;
      let taxPrice = (price / 100) * productGST;
      let subtotal = taxPrice + price;
      setProductTotal(subtotal);
    }
    if (e.target.name === "productGST") {
      setProductGST(e.target.value);
    }
    if (e.target.name === "customize") {
      let eventValue = e.target.value;
      setCutomizeOption(eventValue);
    }
    if (e.target.name === "customize_image") {
      var customizeImage = e.target.files[0];
      var fileSize = e.target.files[0].size;
      if (fileSize > 3e6) {
        toast.error("Image size too large, Send it via email");
        return false;
      }
      if (!customizeImage.name.match(/\.(jpg|jpeg|png|gif|pdf|doc)$/)) {
        toast.error("Please select valid image jpeg,png,gif.");
        return false;
      }
      setCustomizeName(e.target.files[0].name);
      setCustomizeImage(customizeImage);
    }
  };

  const cancelCustomise = () => {
    setCustomizeName("");
    setCustomizeImage("");
    setCutomizeOption("");
  };

  const closeShowEditModel = () => {
    setShowEditModal(false);
    setCutomizeOption("no");
    setCustomizeImage("");
    setProductPrice("");
    setSalesPrice("");
    setProductTotal(0);
    setSalesTotal(0);
    setProductId("");
    setProductGST("");
    setProductQuantity("");
    setCustomizeName("");
  };

  const updateCustomerData = () => {
    const config = {
      headers: {
        "content-type": "multipart/form-data",
        Authorization: `Bearer ${localStorage.getItem("jwtToken")}`,
      },
    };
    const formData = new FormData();
    formData.append("productId", productId);
    formData.append("productGST", productGST);
    formData.append("productQuantity", productQuantity);
    formData.append("productPrice", salesPrice);
    formData.append("productIsCustomize", cutomizeOption);
    formData.append("customizeImage", customizeImage);
    formData.append("avaliableQty", avaliableQty);

    axios
      .post(baseUrl + "/frontapi/addNewOrderSalsePerson", formData, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === true) {
          toast.success(resp.message);
          setShowEditModal(false);
          setCutomizeOption("");
          setCustomizeImage("");
          setProductPrice("");
          setSalesPrice("");
          setProductTotal(0);
          setSalesTotal(0);
          setProductId("");
          setProductGST("");
          setProductQuantity("");
          setCustomizeName("");
          getCartDataByUserId();
        }
        if (resp.status === false) {
          toast.error(resp.message);
        }
      });
  };

  const onModalClick = () => {
    setShowEditModal(true);
  };

  const checkCall = () => {
    return false;
  };

  const Conn = (getMethodDeleteId) => {
    confirmAlert({
      title: "Confirm to submit",
      message: "Are you sure to do this.",
      buttons: [
        {
          label: "Yes",
          onClick: () => deleted(getMethodDeleteId),
        },
        {
          label: "No",
          onClick: () => checkCall(),
        },
      ],
    });
  };

  const deleted = (id) => {
    const data = {
      deleteId: id,
    };
    // cart-delete-by-Id

    axios.post(baseUrl + "/frontapi/deleteCartById", data).then((res) => {
      var resp = res.data;
      if (resp.status === false) {
        toast.dismiss();
        toast.error(resp.message);
        return;
      }
      if (resp.status === true) {
        getCartDataByUserId();
      }
    });
  };

  return (
    <div>
      <Header />
      <div id="page-content">
        <div className="collection-header">
          <div className="collection-hero">
            <div className="collection-hero__image" />
            <div className="collection-hero__title-wrapper container">
              <h1 className="collection-hero__title">Add Products</h1>
              <div className="breadcrumbs text-uppercase mt-1 mt-lg-2">
                <Link to={"/dashboard"}>Home</Link>
                <span>|</span>
                <span className="fw-bold">Add Products</span>
              </div>
            </div>
          </div>
        </div>
        <div className="container">
          <div className="row">
            <div className="col-12">
              <h2 className="title fs-6">Add Products</h2>
              <table className="table-responsive cart active-order-table align-middle">
                <thead className="cart__row cart__header small--hide">
                  <tr>
                    <th className="text-center">Product Name</th>
                    <th className="text-center">Sales Price</th>
                    <th className="text-center">Product Quantity</th>
                    <th className="text-center">Product GST</th>
                    <th className="text-center">Product Total</th>
                    <th className="text-center">Product Customize</th>
                    <th className="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>{dataTr()}</tbody>
              </table>
              {/* <form>{dataTr()}</form> */}
              <div className="row align-items-end">
                <div className="col-md-6 col-12">
                  <h5>Grand Total: {subTotalHtml()} ₹</h5>
                  {tableData.length > 0 ? (
                    <a href="/select-customer" className="btn btn-primary">
                      Continue
                    </a>
                  ) : (
                    <a className="btn btn-primary" href="#!">
                      Add Order
                    </a>
                  )}
                </div>
                <div className="col-md-6 col-12 text-right">
                  <div className="add-row-btn">
                    <a
                      href="#!"
                      className="btn btn-primary"
                      onClick={onModalClick}
                    >
                      +
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Modal
            className="modal-update add-product-update"
            show={showEditModal}
            onHide={closeShowEditModel}
          >
            <Modal.Header closeButton>
              <Modal.Title className="m-0"> Add Products To Cart</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="row">
                <div className="col-md-6 col-12">
                  <label>Product Name</label>
                  <div className="product-price form-group">
                    <select
                      className="form-control"
                      name="productId"
                      value={productId}
                      onChange={handleChange}
                    >
                      <option>Select Product</option>
                      {data.map((item) => {
                        return (
                          <option key={item.id} value={item.id}>
                            {item.name}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                </div>{" "}
                <div className="col-md-6 col-12">
                  <label>Product Price</label>
                  <div className="product-price form-group">
                    <input
                      className="form-control"
                      type={"text"}
                      name="productPrice"
                      disabled={true}
                      value={productPrice}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <label>Sales Price</label>
                  <div className="product-price form-group">
                    <input
                      className="form-control"
                      type={"text"}
                      name="salesPrice"
                      // disabled={true}
                      value={salesPrice}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <label>Product Quantity</label>
                  <div className="product-price form-group">
                    <input
                      className="form-control"
                      type={"text"}
                      name="productQuantity"
                      value={productQuantity}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <label>Product GST</label>
                  <div className="product-price form-group">
                    <input
                      className="form-control"
                      type={"text"}
                      name="productGST"
                      value={productGST}
                      disabled={true}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <label>Customized</label>
                  <div className="yes-no-outer form-group d-flex flex-wrap">
                    {cutomizeOption == "yes" ? (
                      <>
                        <div className="upload-file position-relative">
                          <label
                            htmlFor="staticEmail2"
                            className="file-upload-label"
                          >
                            File Upload
                          </label>
                          <input
                            type="file"
                            name="customize_image"
                            onChange={handleChange}
                          />
                          <span>{customizeName}</span>
                        </div>
                        <button onClick={cancelCustomise}>
                          {" "}
                          Cancel{" "}
                        </button>
                      </>
                    ) : (
                      <>
                        <div className="form-check form-check-inline checkbox-main-outer d-flex flex-wrap align-items-center">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="customize"
                            id="inlineRadio1"
                            value={"yes"}
                            onChange={(e) => handleChange(e)}
                          />
                          <label
                            className="form-check-label"
                            htmlFor="inlineRadio1"
                          >
                            Yes
                          </label>
                        </div>
                        <div className="form-check form-check-inline checkbox-main-outer d-flex flex-wrap align-items-center">
                          <input
                            className="form-check-input"
                            type="radio"
                            name="customize"
                            id="inlineRadio2"
                            value={"no"}
                            onChange={(e) => handleChange(e)}
                          />
                          <label
                            className="form-check-label"
                            htmlFor="inlineRadio2"
                          >
                            No
                          </label>
                        </div>
                      </>
                    )}
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <label>Product Price Total</label>
                  <div className="product-price form-group">
                    <h5>{salesTotal}</h5>
                  </div>
                </div>
                <div className="col-md-6 col-12">
                  <label>Sales Price Total</label>
                  <div className="product-price form-group">
                    <h5>{productTotal}</h5>
                  </div>
                </div>
                <div className="col-12">
                  <div className="submit-btn">
                    <button
                      className="cartCheckout fs-6 btn btn-lg rounded w-100 fw-600 text-white"
                      onClick={updateCustomerData}
                    >
                      Add Product
                    </button>
                  </div>
                </div>
              </div>
            </Modal.Body>
          </Modal>
        </div>
      </div>
      <ToastContainer />
      <Footer />
    </div>
  );
};

export default SalsePersonProductForm;

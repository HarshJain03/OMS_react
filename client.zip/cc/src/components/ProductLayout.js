import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "./Header";
import Footer from "./Footer";
import { useParams } from "react-router-dom";
import * as myConstList from "./BaseUrl";
import $ from "jquery";
const baseUrl = myConstList.baseUrl;

function ProductLayout(props) {
  var productId = useParams();
  const [data, setData] = useState([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [color, setColor] = useState("");
  const [tax, setTax] = useState("");
  const [description, setDescription] = useState("");
  const [attribute, setAttribute] = useState([]);
  const [colorP, setColorP] = useState("");
  const [sizeP, setSizeP] = useState("");
  const [qty, setQty] = useState(1);
  const [image, setImage] = useState("");
  const [count, setCount] = useState("");
  const [refreshed, setRefreshed] = useState(new Date().getTime());

  useEffect(() => {
    productSingle();
  }, [refreshed]);

  const DecreaseMargin = () => {
    var qryVar = parseInt(qty) - 1;
    setQty(qryVar);
  };
  const IncrementMargin = () => {
    var qryVar = parseInt(qty) + 1;
    setQty(qryVar);
  };

  const productSingle = async () => {
    await axios
      .post(baseUrl + "/frontapi/product-single", productId)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          setData(resp.data);
          setName(resp.data.sqlRun[0].name);
          setPrice(resp.data.sqlRun[0].sale_price);
          setColor(resp.data.sqlRun[0].price);
          setTax(resp.data.sqlRun[0].tax);
          setAttribute(resp.data.sqlRun2);
          setImage(resp.data.sqlRun[0].image);
          htmlAttribute(resp.data.sqlRun2);
          setDescription(resp.data.sqlRun[0].description);
        } else {
          toast.dismiss();
          toast.error(resp.message);
          return;
        }
      });
  };

  const htmlAttribute = async (attribute) => {
    attribute.map(async (value, i) => {
      if (value.valueName === "colour") {
        setColorP(value.value);
      }
      if (value.valueName === "size") {
        setSizeP(value.value);
      }
    });
  };
  const imageDataHtml = () => {
    const html = [];
    if (image) {
      let allImages = image.split(",");

      html.push(
        <div class="detail-left">
          <img
            id="singleImage"
            src={baseUrl + "/static" + allImages[0]}
            alt=""
            class="img-fluid"
          />
        </div>
      );
      // allImages.map(function (value, i) {
      //   return html.push(
      //     <div class="col-md-3">
      //       <div class="item-images">
      //         <a href="#">
      //           <img
      //             src={baseUrl + "/static" + value}
      //             onClick={() => changeImage(baseUrl + "/static" + value)}
      //             alt=""
      //             class="img-fluid"
      //             width="500"
      //             height="600"
      //           />
      //         </a>
      //       </div>
      //     </div>
      //   );
      // });
    }
    return html;
  };
  const changeImage = (image_link) => {
    $("#singleImage").attr("src", image_link);
  };

  const detailsHtml = () => {
    var html = [];
    attribute.map((item, i) => {
      html.push(
        <div className="product-color-select product-form__item form-group d-flex align-items-center justify-content-between">
          {/* <label className="label mb-0">Color : </label>  <span className="slVariant ms-1 fw-bold">{colorP}</span> */}
          <label className="label d-flex">
            {item.valueName}:<span className="required d-none">*</span>
            <span className="slVariant ms-1 fw-bold">{item.value}</span>
          </label>
        </div>
      );
    });
    return html;
  };

  const addCart = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    let params = {
      productId: productId.id,
      qty: qty,
    };
    await axios
      .post(baseUrl + "/frontapi/add-cart", params, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === false) {
          toast.dismiss();
          toast.error(resp.message);
          return;
        }
        if (resp.status === true) {
          toast.success(resp.message);
          setData(resp.data);
        }
      });
  };

  return (
    <>
      <Header />
      <div id="page-content">
        <>
          <div id="page-content">
            <div className="breadcrumbs-wrapper text-uppercase">
              <div className="container">
                <div className="breadcrumbs">
                  <a href="/dashboard" title="Back to the home page">
                    Home
                  </a>
                  <span>|</span>
                  <span className="fw-bold">Product Layout Style1</span>
                </div>
              </div>
            </div>
            <div className="container">
              <div className="product-single">
                <div className="row">
                  <div className="col-lg-7 col-md-6 col-sm-12 col-12">
                    <div className="product-details-img thumb-left clearfix d-flex-wrap mb-3 mb-md-0">
                      {imageDataHtml()}
                    </div>
                  </div>
                  <div className="col-lg-5 col-md-6 col-sm-12 col-12">
                    <div className="product-single__meta">
                      <h1 className="product-single__title">{name}</h1>
                      <div className="product-single__price pb-1">
                        <span className="visually-hidden">Regular price</span>
                        <span className="product-price__sale--single">
                          <div className="slVariant ms-1 fw-bold">
                            Net Price
                            <span className="slVariant ms-2 fw-bold">
                              {"₹" + price}
                            </span>
                          </div>
                          <div className="slVariant ms-1 fw-bold">
                            GST
                            <span className="slVariant ms-2 fw-bold">
                              {tax + "%"}
                            </span>
                          </div>
                          <div className="slVariant ms-1 fw-bold">
                            GST Inclusive Price
                            <span className="slVariant ms-2 fw-bold">
                              {"₹" + (price + (price * tax) / 100)}
                            </span>
                          </div>
                        </span>
                      </div>
                    </div>
                    <div
                      className="swatches-image swatch clearfix swatch-0 option1"
                      data-option-index={0}
                    >
                      {detailsHtml()}
                    </div>
                    <div className="product-action w-100 clearfix">
                      {localStorage.getItem("userType") === "customer" && (
                        <div className="product-form__item--quantity d-flex-center mb-3">
                          <div className="qtyField">
                            <button
                              className="qtyBtn minus"
                              type="button"
                              onClick={DecreaseMargin}
                            >
                              -
                            </button>
                            <input
                              type="text"
                              name="quantity"
                              value={qty}
                              className="product-form__input qty"
                            />
                            <button
                              className="qtyBtn plus"
                              type="button"
                              onClick={IncrementMargin}
                            >
                              +
                            </button>
                          </div>
                        </div>
                      )}
                      <div className="product-form__item--submit">
                        {localStorage.getItem("userType") === "customer" && (
                          <button
                            name="add"
                            className="btn rounded product-form__cart-submit"
                            onClick={addCart}
                          >
                            <span>Add to cart</span>
                          </button>
                        )}
                        <button
                          type="submit"
                          name="add"
                          className="btn rounded product-form__sold-out d-none"
                          disabled="disabled"
                        >
                          Sold out
                        </button>
                      </div>
                      {localStorage.getItem("userType") === "customer" ? (
                        <div className="product-form__item--buyit clearfix">
                          <Link
                            to={"/cart"}
                            type="button"
                            className="btn rounded btn-outline-primary proceed-to-checkout"
                          >
                            Buy it now
                          </Link>
                        </div>
                      ) : (
                        <div className="product-form__item--buyit clearfix">
                          <Link
                            to={"/product-form"}
                            type="button"
                            className="btn rounded btn-outline-primary proceed-to-checkout"
                          >
                            Add Orders
                          </Link>
                        </div>
                      )}
                      <div className="agree-check customCheckbox clearfix d-none">
                        <input
                          id="prTearm"
                          name="tearm"
                          type="checkbox"
                          defaultValue="tearm"
                          required=""
                        />
                        <label htmlFor="prTearm">
                          I agree with the terms and conditions
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="tabs-listing">
                <ul className="product-tabs list-unstyled d-flex-wrap border-bottom m-0 d-none d-md-flex">
                  <li>
                    {/* <a href="#!"> */}
                    Description
                    {/* </a> */}
                  </li>
                </ul>
                <h3
                  className="tabs-ac-style d-md-none active"
                  rel="description"
                >
                  Description
                </h3>
                <div id="description" className="tab-content">
                  <div className="product-description">
                    <div className="row">
                      <div className="col-12 col-sm-12 col-md-8 col-lg-8 mb-4 mb-md-0">
                        <p>{description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <span id="site-scroll">
              <i className="icon an an-chevron-up" />
            </span>
            <div className="modalOverly" />
            <div id="ShippingInfo" className="mfpbox mfp-with-anim mfp-hide">
              <h5>DELIVERY</h5>
              <ul>
                <li>Dispatch: Within 24 Hours</li>
                <li>
                  Free shipping across all products on a minimum purchase of
                  $50.
                </li>
                <li>International delivery time - 7-10 business days</li>
                <li>Cash on delivery might be available</li>
                <li>Easy 30 days returns and exchanges</li>
              </ul>
              <h5>RETURNS</h5>
              <p>
                If you do not like the product you can return it within 15 days
                - no questions asked. This excludes bodysuits, swimwear and
                clearance sale items. We have an easy and hassle free return
                policy. Please look at our Delivery &amp; Returns section for
                further information.
              </p>
            </div>
            <div id="productInquiry" className="mfpbox mfp-with-anim mfp-hide">
              <div className="contact-form form-vertical p-lg-1">
                <div className="page-title">
                  <h3>Product Inquiry Popup</h3>
                </div>
                <form
                  method="post"
                  action="#"
                  id="contact_form"
                  className="contact-form"
                >
                  <div className="formFeilds">
                    <div className="row">
                      <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                        <div className="form-group">
                          <input
                            type="text"
                            id="ContactFormName"
                            name="contact[name]"
                            placeholder="Name"
                            defaultValue=""
                            required=""
                          />
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                        <div className="form-group">
                          <input
                            type="email"
                            id="ContactFormEmail"
                            name="contact[email]"
                            placeholder="Email"
                            defaultValue=""
                            required=""
                          />
                        </div>
                      </div>
                      <div className="col-12 col-sm-12 col-md-6 col-lg-6">
                        <div className="form-group">
                          <input
                            type="tel"
                            id="ContactFormPhone"
                            name="contact[phone]"
                            pattern="[0-9\-]*"
                            placeholder="Phone Number"
                            defaultValue=""
                            required=""
                          />
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                        <div className="form-group">
                          <input
                            type="text"
                            id="ContactFormSubject"
                            name="contact[subject]"
                            placeholder="Subject"
                            defaultValue=""
                            required=""
                          />
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                        <div className="form-group">
                          <textarea
                            rows={8}
                            id="ContactFormMessage"
                            name="contact[body]"
                            placeholder="Message"
                            required=""
                            defaultValue={""}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                        <input
                          type="submit"
                          className="btn rounded w-100"
                          defaultValue="Send Message"
                        />
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div className="loadingBox">
              <div className="an-spin">
                <i className="icon an an-spinner4" />
              </div>
            </div>
            <div id="quickView-modal" className="mfp-with-anim mfp-hide">
              <button title="Close (Esc)" type="button" className="mfp-close">
                ×
              </button>
              <div className="row">
                <div className="col-12 col-sm-6 col-md-6 col-lg-6 mb-3 mb-md-0">
                  <div id="quickView" className="carousel slide">
                    <div className="carousel-inner">
                      <div
                        className="item carousel-item active"
                        data-bs-slide-number={0}
                      >
                        <img
                          className="blur-up lazyload"
                          data-src="../../assets/images/products/product-5.jpg"
                          src="../../assets/images/products/product-5.jpg"
                          alt=""
                          title=""
                        />
                      </div>
                      <div
                        className="item carousel-item"
                        data-bs-slide-number={1}
                      >
                        <img
                          className="blur-up lazyload"
                          data-src="../../assets/images/products/product-5-1.jpg"
                          src="../../assets/images/products/product-5-1.jpg"
                          alt=""
                          title=""
                        />
                      </div>
                      <div
                        className="item carousel-item"
                        data-bs-slide-number={2}
                      >
                        <img
                          className="blur-up lazyload"
                          data-src="../../assets/images/products/product-5-2.jpg"
                          src="../../assets/images/products/product-5-2.jpg"
                          alt=""
                          title=""
                        />
                      </div>
                      <div
                        className="item carousel-item"
                        data-bs-slide-number={3}
                      >
                        <img
                          className="blur-up lazyload"
                          data-src="../../assets/images/products/product-5-3.jpg"
                          src="../../assets/images/products/product-5-3.jpg"
                          alt=""
                          title=""
                        />
                      </div>
                      <div
                        className="item carousel-item"
                        data-bs-slide-number={4}
                      >
                        <img
                          className="blur-up lazyload"
                          data-src="../../assets/images/products/product-5-4.jpg"
                          src="../../assets/images/products/product-5-4.jpg"
                          alt=""
                          title=""
                        />
                      </div>
                    </div>
                    <div className="model-thumbnail-img">
                      <div className="carousel-indicators list-inline">
                        <div
                          className="list-inline-item active"
                          id="carousel-selector-0"
                          data-bs-slide-to={0}
                          data-bs-target="#quickView"
                        >
                          <img
                            className="blur-up lazyload"
                            data-src="../../assets/images/products/product-5.jpg"
                            src="../../assets/images/products/product-5.jpg"
                            alt=""
                            title=""
                          />
                        </div>
                        <div
                          className="list-inline-item"
                          id="carousel-selector-1"
                          data-bs-slide-to={1}
                          data-bs-target="#quickView"
                        >
                          <img
                            className="blur-up lazyload"
                            data-src="../../assets/images/products/product-5-1.jpg"
                            src="../../assets/images/products/product-5-1.jpg"
                            alt=""
                            title=""
                          />
                        </div>
                        <div
                          className="list-inline-item"
                          id="carousel-selector-2"
                          data-bs-slide-to={2}
                          data-bs-target="#quickView"
                        >
                          <img
                            className="blur-up lazyload"
                            data-src="../../assets/images/products/product-5-2.jpg"
                            src="../../assets/images/products/product-5-2.jpg"
                            alt=""
                            title=""
                          />
                        </div>
                        <div
                          className="list-inline-item"
                          id="carousel-selector-3"
                          data-bs-slide-to={3}
                          data-bs-target="#quickView"
                        >
                          <img
                            className="blur-up lazyload"
                            data-src="../../assets/images/products/product-5-3.jpg"
                            src="../../assets/images/products/product-5-3.jpg"
                            alt=""
                            title=""
                          />
                        </div>
                        <div
                          className="list-inline-item"
                          id="carousel-selector-4"
                          data-bs-slide-to={4}
                          data-bs-target="#quickView"
                        >
                          <img
                            className="blur-up lazyload"
                            data-src="../../assets/images/products/product-5-4.jpg"
                            src="../../assets/images/products/product-5-4.jpg"
                            alt=""
                            title=""
                          />
                        </div>
                      </div>
                      <a
                        className="carousel-control-prev carousel-arrow"
                        href="#quickView"
                        data-bs-target="#quickView"
                        data-bs-slide="prev"
                      >
                        <i className="icon an-3x an an-angle-left" />
                        <span className="visually-hidden">Previous</span>
                      </a>
                      <a
                        className="carousel-control-next carousel-arrow"
                        href="#quickView"
                        data-bs-target="#quickView"
                        data-bs-slide="next"
                      >
                        <i className="icon an-3x an an-angle-right" />
                        <span className="visually-hidden">Next</span>
                      </a>
                    </div>
                  </div>
                  <div className="text-center mt-3">
                    <a href="product-layout1.html">VIEW MORE DETAILS</a>
                  </div>
                </div>
                <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                  <h2 className="product-title">Product Quick View Popup</h2>
                  <div className="product-review d-flex-center mb-2">
                    <div className="rating">
                      <i className="icon an an-star" />
                      <i className="icon an an-star" />
                      <i className="icon an an-star" />
                      <i className="icon an an-star" />
                      <i className="icon an an-star-o" />
                    </div>
                    <div className="reviews ms-2">
                      <a href="#!">5 Reviews</a>
                    </div>
                  </div>
                  <div className="product-info">
                    <p className="product-vendor">
                      Vendor:{" "}
                      <span className="fw-normal">
                        <a href="#!" className="fw-normal">
                          Optimal
                        </a>
                      </span>
                    </p>
                    <p className="product-type">
                      Product Type: <span className="fw-normal">Tops</span>
                    </p>
                    <p className="product-sku">
                      SKU: <span className="fw-normal">50-ABC</span>
                    </p>
                  </div>
                  <div className="pro-stockLbl my-2">
                    <span className="d-flex-center stockLbl instock">
                      <i className="icon an an-check-cil" />
                      <span> In stock</span>
                    </span>
                    <span className="d-flex-center stockLbl preorder d-none">
                      <i className="icon an an-clock-r" />
                      <span> Pre-order Now</span>
                    </span>
                    <span className="d-flex-center stockLbl outstock d-none">
                      <i className="icon an an-times-cil" />{" "}
                      <span>Sold out</span>
                    </span>
                    <span
                      className="d-flex-center stockLbl lowstock d-none"
                      data-qty={15}
                    >
                      <i className="icon an an-exclamation-cir" />
                      <span>
                        {" "}
                        Order now, Only <span className="items">10</span>
                        left!
                      </span>
                    </span>
                  </div>
                  <div className="pricebox">
                    <span className="price old-price">$400.00</span>
                    <span className="price product-price__sale">$300.00</span>
                  </div>
                  <div className="sort-description">
                    Optimal Multipurpose Bootstrap 5 Html Template that will
                    give you and your customers a smooth shopping experience
                    which can be used for various kinds of stores such as
                    fashion..
                  </div>
                  <form
                    method="post"
                    action="#"
                    id="product_form--option"
                    className="product-form"
                  >
                    <div className="product-options d-flex-wrap">
                      <div className="swatch clearfix swatch-0 option1">
                        <div className="product-form__item">
                          <label className="label d-flex">
                            Color:<span className="required d-none">*</span>{" "}
                            <span className="slVariant ms-1 fw-bold">
                              Black
                            </span>
                          </label>
                          <ul className="swatches-image swatches d-flex-wrap list-unstyled clearfix">
                            <li
                              data-value="Black"
                              className="swatch-element color available active"
                            >
                              <label
                                className="rounded swatchLbl small color black"
                                title="Black"
                              />
                              <span className="tooltip-label top">Black</span>
                            </li>
                            <li
                              data-value="Green"
                              className="swatch-element color available"
                            >
                              <label
                                className="rounded swatchLbl small color green"
                                title="Green"
                              />
                              <span className="tooltip-label top">Green</span>
                            </li>
                            <li
                              data-value="Orange"
                              className="swatch-element color available"
                            >
                              <label
                                className="rounded swatchLbl small color orange"
                                title="Orange"
                              />
                              <span className="tooltip-label top">Orange</span>
                            </li>
                            <li
                              data-value="Blue"
                              className="swatch-element color available"
                            >
                              <label
                                className="rounded swatchLbl small color blue"
                                title="Blue"
                              />
                              <span className="tooltip-label top">Blue</span>
                            </li>
                            <li
                              data-value="Red"
                              className="swatch-element color available"
                            >
                              <label
                                className="rounded swatchLbl small color red"
                                title="Red"
                              />
                              <span className="tooltip-label top">Red</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div className="swatch clearfix swatch-1 option2">
                        <div className="product-form__item">
                          <label className="label">
                            Size:<span className="required d-none">*</span>{" "}
                            <span className="slVariant ms-1 fw-bold">XS</span>
                          </label>
                          <ul className="swatches-size d-flex-center list-unstyled clearfix swatch-1 option2">
                            <li
                              data-value="XS"
                              className="swatch-element xs available active"
                            >
                              <label
                                className="swatchLbl rounded medium"
                                title="XS"
                              >
                                XS
                              </label>
                              <span className="tooltip-label">XS</span>
                            </li>
                            <li
                              data-value="S"
                              className="swatch-element s available"
                            >
                              <label
                                className="swatchLbl rounded medium"
                                title="S"
                              >
                                S
                              </label>
                              <span className="tooltip-label">S</span>
                            </li>
                            <li
                              data-value="M"
                              className="swatch-element m available"
                            >
                              <label
                                className="swatchLbl rounded medium"
                                title="M"
                              >
                                M
                              </label>
                              <span className="tooltip-label">M</span>
                            </li>
                            <li
                              data-value="L"
                              className="swatch-element l available"
                            >
                              <label
                                className="swatchLbl rounded medium"
                                title="L"
                              >
                                L
                              </label>
                              <span className="tooltip-label">L</span>
                            </li>
                            <li
                              data-value="XL"
                              className="swatch-element xl available"
                            >
                              <label
                                className="swatchLbl rounded medium"
                                title="XL"
                              >
                                XL
                              </label>
                              <span className="tooltip-label">XL</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div className="product-action d-flex-wrap w-100 mb-3 clearfix">
                        <div className="quantity">
                          <div className="qtyField rounded">
                            <a className="qtyBtn minus" href="#!">
                              <i
                                className="icon an an-minus-r"
                                aria-hidden="true"
                              />
                            </a>
                            <input
                              type="text"
                              name="quantity"
                              defaultValue={1}
                              className="product-form__input qty"
                            />
                            <a className="qtyBtn plus" href="#!">
                              <i
                                className="icon an an-plus-l"
                                aria-hidden="true"
                              />
                            </a>
                          </div>
                        </div>
                        <div className="add-to-cart ms-3 fl-1">
                          <button
                            type="button"
                            className="btn button-cart rounded"
                            onClick={addCart}
                          >
                            <span>Add to cart</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                  <div className="wishlist-btn d-flex-center">
                    <a
                      className="add-wishlist d-flex-center text-uppercase me-3"
                      href="my-wishlist.html"
                      title="Add to Wishlist"
                    >
                      <i className="icon an an-heart-l me-1" />{" "}
                      <span>Add to Wishlist</span>
                    </a>
                    <a
                      className="add-compare d-flex-center text-uppercase"
                      href="compare-style1.html"
                      title="Add to Compare"
                    >
                      <i className="icon an an-random-r me-2" />{" "}
                      <span>Add to Compare</span>
                    </a>
                  </div>
                  <div className="social-sharing share-icon d-flex-center mx-0 mt-3">
                    <span className="sharing-lbl me-2">Share :</span>
                    <a
                      href="#!"
                      className="d-flex-center btn btn-link btn--share share-facebook"
                      data-bs-toggle="tooltip"
                      data-bs-placement="top"
                      title="Share on Facebook"
                    >
                      <i className="icon an an-facebook mx-1" />
                      <span className="share-title d-none">Facebook</span>
                    </a>
                    <a
                      href="#!"
                      className="d-flex-center btn btn-link btn--share share-twitter"
                      data-bs-toggle="tooltip"
                      data-bs-placement="top"
                      title="Tweet on Twitter"
                    >
                      <i className="icon an an-twitter mx-1" />
                      <span className="share-title d-none">Tweet</span>
                    </a>
                    <a
                      href="#!"
                      className="d-flex-center btn btn-link btn--share share-pinterest"
                      data-bs-toggle="tooltip"
                      data-bs-placement="top"
                      title="Pin on Pinterest"
                    >
                      <i className="icon an an-pinterest-p mx-1" />{" "}
                      <span className="share-title d-none">Pin it</span>
                    </a>
                    <a
                      href="#!"
                      className="d-flex-center btn btn-link btn--share share-linkedin"
                      data-bs-toggle="tooltip"
                      data-bs-placement="top"
                      title="Share on Instagram"
                    >
                      <i className="icon an an-instagram mx-1" />
                      <span className="share-title d-none">Instagram</span>
                    </a>
                    <a
                      href="#!"
                      className="d-flex-center btn btn-link btn--share share-whatsapp"
                      data-bs-toggle="tooltip"
                      data-bs-placement="top"
                      title="Share on WhatsApp"
                    >
                      <i className="icon an an-whatsapp mx-1" />
                      <span className="share-title d-none">WhatsApp</span>
                    </a>
                    <a
                      href="#!"
                      className="d-flex-center btn btn-link btn--share share-email"
                      data-bs-toggle="tooltip"
                      data-bs-placement="top"
                      title="Share by Email"
                    >
                      <i className="icon an an-envelope-l mx-1" />
                      <span className="share-title d-none">Email</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div id="pro-addtocart-popup" className="mfp-with-anim mfp-hide">
              <button title="Close (Esc)" type="button" className="mfp-close">
                ×
              </button>
              <div className="addtocart-inner text-center clearfix">
                <h4 className="title mb-3 text-success">
                  Added to your shopping cart successfully.
                </h4>
                <div className="pro-img mb-3">
                  <img
                    className="img-fluid blur-up lazyload"
                    src="../../assets/images/products/add-to-cart-popup.jpg"
                    data-src="../../assets/images/products/add-to-cart-popup.jpg"
                    alt="Added to your shopping cart successfully."
                    title="Added to your shopping cart successfully."
                  />
                </div>
                <div className="pro-details">
                  <h5 className="pro-name mb-0">Ditsy Floral Dress</h5>
                  <p className="sku my-2">Color: Gray</p>
                  <p className="mb-0 qty-total">1 X $113.88</p>
                  <div className="addcart-total bg-light mt-3 mb-3 p-2">
                    Total: <b className="price">$113.88</b>
                  </div>
                  <div className="button-action">
                    <a
                      href="checkout.html"
                      className="btn btn-primary view-cart mx-1 rounded"
                    >
                      Go To Checkout
                    </a>
                    <a href="index.html" className="btn btn-secondary rounded">
                      Continue Shopping
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div
              className="pswp"
              tabIndex={-1}
              role="dialog"
              aria-hidden="true"
            >
              <div className="pswp__bg" />
              <div className="pswp__scroll-wrap">
                <div className="pswp__container">
                  <div className="pswp__item" />
                  <div className="pswp__item" />
                  <div className="pswp__item" />
                </div>
                <div className="pswp__ui pswp__ui--hidden">
                  <div className="pswp__top-bar">
                    <div className="pswp__counter" />
                    <button
                      className="pswp__button pswp__button--close"
                      title="Close (Esc)"
                    />
                    <button
                      className="pswp__button pswp__button--share"
                      title="Share"
                    />
                    <button
                      className="pswp__button pswp__button--fs"
                      title="Toggle fullscreen"
                    />
                    <button
                      className="pswp__button pswp__button--zoom"
                      title="Zoom in/out"
                    />
                    <div className="pswp__preloader">
                      <div className="pswp__preloader__icn">
                        <div className="pswp__preloader__cut">
                          <div className="pswp__preloader__donut" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                    <div className="pswp__share-tooltip" />
                  </div>
                  <button
                    className="pswp__button pswp__button--arrow--left"
                    title="Previous (arrow left)"
                  />
                  <button
                    className="pswp__button pswp__button--arrow--right"
                    title="Next (arrow right)"
                  />
                  <div className="pswp__caption">
                    <div className="pswp__caption__center" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
        <ToastContainer limit={1} />
        <Footer refreshed={refreshed} setRefreshed={setRefreshed} />
      </div>
    </>
  );
}
export default ProductLayout;

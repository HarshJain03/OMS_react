import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Dashboard from "./components/Index";
import ProductLayout from "./components/ProductLayout";
import Checkout from "./components/Checkout";
import Cart from "./components/Cart";
import CheckoutSuccess from "./components/CheckoutSuccess";
import ActiveOrders from "./components/ActiveOrders";
import OrderHistory from "./components/OrderHistory";
import Login from "./components/Login";
import CustomerSelection from "./components/CustomerSelection";
import SalsePersonProductForm from "./components/SalsePersonProductForm";
import NotFound from "./components/NotFound";

function App() {
  return (
    <Router>
      {localStorage.getItem("userType") === "customer" ? (
        <div className="app-container">
          <Routes>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/product-detail/:id" element={<ProductLayout />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout-success" element={<CheckoutSuccess />} />
            <Route path="/active-orders" element={<ActiveOrders />} />
            <Route path="/order-history" element={<OrderHistory />} />
            {/* <Route path="/select-customer" element={<CustomerSelection />} /> */}
            {/* <Route path="/product-form" element={<SalsePersonProductForm />} /> */}
            <Route path="/" element={<Login />} />
            <Route exact path="*" element={<NotFound />} />
          </Routes>
        </div>
      ) : (
        <div className="app-container">
          <Routes>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/product-detail/:id" element={<ProductLayout />} />
            {/* <Route path="/checkout" element={<Checkout />} /> */}
            {/* <Route path="/cart" element={<Cart />} /> */}
            <Route path="/checkout-success" element={<CheckoutSuccess />} />
            <Route path="/active-orders" element={<ActiveOrders />} />
            <Route path="/order-history" element={<OrderHistory />} />
            <Route path="/select-customer" element={<CustomerSelection />} />
            <Route path="/product-form" element={<SalsePersonProductForm />} />
            <Route path="/" element={<Login />} />
            <Route exact path="*" element={<NotFound />} />
          </Routes>
        </div>
      )}
    </Router>
  );
}
export default App;

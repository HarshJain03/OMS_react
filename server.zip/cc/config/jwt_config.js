// config.js
module.exports = {
  'secret': 'YdKKdviKKdlvppjciv767skmlkk3dl'
};
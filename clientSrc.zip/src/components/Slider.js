import React from "react";
import Sliders from 'react-slick'; 

var settings = {
  infinite: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2500,
  fade: false,
  dots: true,
  arrows: true,
  pauseOnHover: false,
  pauseOnFocus: false,
};

function Slider() {
  return (
    <section className="slideshow slideshow-wrapper">
       
      <div className="home-slideshow">
      <Sliders {...settings}> 
        <div className="slide">
          <div className="blur-up lazyload">
            <img
              className="blur-up lazyload desktop-hide"
              data-src="assets/images/slideshow/demo1-banner1.jpg"
              src="assets/images/slideshow/demo1-banner1.jpg"
              alt="HIGH CONVERTING"
              title="HIGH CONVERTING"
              width={2000}
              height={840}
            />
            <img
              className="blur-up lazyload mobile-hide"
              data-src="assets/images/slideshow/demo1-banner1-m.jpg"
              src="assets/images/slideshow/demo1-banner1-m.jpg"
              alt="HIGH CONVERTING"
              title="HIGH CONVERTING"
              width={705}
              height={780}
            />
            <div className="container">
              <div className="slideshow-content slideshow-overlay bottom-middle d-flex justify-content-center align-items-center">
                <div className="slideshow-content-in text-center">
                  <div className="wrap-caption animation style2 whiteText px-2">
                    <h1 className="h1 mega-title ss-mega-title fs-1">
                      HIGH CONVERTING
                    </h1>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
       
        <div className="slide">
          <div className="blur-up lazyload">
            <img
              className="blur-up lazyload desktop-hide"
              data-src="assets/images/slideshow/demo1-banner2.jpg"
              src="assets/images/slideshow/demo1-banner2.jpg"
              alt="MAKING BRAND VISIBLE"
              title="MAKING BRAND VISIBLE"
              width={2000}
              height={840}
            />
            <img
              className="blur-up lazyload mobile-hide"
              data-src="assets/images/slideshow/demo1-banner2-m.jpg"
              src="assets/images/slideshow/demo1-banner2-m.jpg"
              alt="MAKING BRAND VISIBLE"
              title="MAKING BRAND VISIBLE"
              width={705}
              height={780}
            />
            <div className="slideshow-content slideshow-overlay bottom-middle container d-flex justify-content-center align-items-center">
              <div className="slideshow-content-in text-center">
                <div className="wrap-caption animation style2 whiteText px-2">
                  <h2 className="mega-title ss-mega-title fs-1">
                    MAKING BRAND VISIBLE
                  </h2>
                </div>
              </div>
            </div>
          </div>
        </div>
        </Sliders>
      </div>     
    </section>
  );
}
export default Slider;

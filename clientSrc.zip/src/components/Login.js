import React, { useState, useEffect } from "react";
import axios from "axios";
import { Toaster, toast } from "react-hot-toast";
import "react-toastify/dist/ReactToastify.css";
import jwt_decode from "jwt-decode";
import * as myConstList from "./BaseUrl";
const baseUrl = myConstList.baseUrl;

function Login() {
  const [Email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isChecked, setisChecked] = useState(false);

  useEffect(() => {
    if (localStorage.checkbox && localStorage.email !== "") {
      setisChecked(true);
      setEmail(localStorage.email);
      setPassword(localStorage.password);
    }
    if (localStorage.getItem("jwtToken")) {
      window.location = "/dashboard";
    }
  }, []);
  const handleChangeEmail = async (event) => {
    let eventValue = event.target.value;
    setEmail(eventValue);
  };
  const handlePassword = async (event) => {
    let eventValue = event.target.value;
    setPassword(eventValue);
  };
  const handleOnBlurEmail = async (event) => {
    var eventValue = await event.target.value;
    var Email1Reg = new RegExp(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,15}/g).test(
      Email
    );
    if (!eventValue) {
      toast.dismiss();
      toast.error("Enter Email Address",{position: "top-right"});
      return false;
    }
    if (!Email1Reg) {
      toast.dismiss();
      toast.error("Enter valid Email Address",{position: "top-right"});
      return false;
    }
  };
  const handleOnBlurPassword = async (event) => {
    var password = await event.target.value;
    if (!password) {
      toast.dismiss();
      toast.error("Password required",{position: "top-right"});
      return false;
    }
  };

  const handleSubmit = async (event) => {
    if (event.key === "Enter") {
      console.log("do validate");
    }
    event.preventDefault();
    let LoginData = {
      email: Email,
      password: password,
    };
    axios.post(baseUrl + "/frontapi/login-user", LoginData).then((resp) => {
      var resp = resp.data;

      if (resp.status === false) {
        toast.dismiss();
        toast.error(resp.message,{position: "right"
      });
        return;
      }
      if (resp.status == true) {
        localStorage.setItem("email", Email);
        // localStorage.setItem("password", password);
        localStorage.setItem("userType", resp.data[0].userType);
        let token = resp.token;
        localStorage.setItem("jwtToken", token);
        const decoded = jwt_decode(token);
        toast.success("Login Successfully",{position: "top-right"});
        setTimeout(
          function () {
            window.location = "/dashboard";
          }.bind(this),
          3000
        );
      }
    });
  };

  return (
    <>
      <div id="page-content">
        <>
          <div id="page-content">
            <div className="collection-header">
              <div className="collection-hero">
                <div className="collection-hero__image" />
                <div className="collection-hero__title-wrapper container">
                  <h1 className="collection-hero__title">Login</h1>
                  <div className="breadcrumbs text-uppercase mt-1 mt-lg-2">
                    <a href="../index.html" title="Back to the home page">
                      Home
                    </a>
                    <span>|</span>
                    <span className="fw-bold">Login</span>
                  </div>
                </div>
              </div>
            </div>
            {/*End Collection Banner*/}
            {/*Container*/}
            <div className="container">
              {/*Main Content*/}
              <div className="login-register pt-2 pt-lg-5">
                <div className="row">
                  <div className="col-12">
                    <div className="inner">
                      <form method="post" action="#" className="customer-form">
                        <h3 className="h4 text-uppercase">
                          REGISTERED CUSTOMERS
                        </h3>
                        <p>If you have an account with us, please log in.</p>
                        <div className="row">
                          <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                            <div className="form-group">
                              <label htmlFor="CustomerEmail" className="d-none">
                                Email <span className="required">*</span>
                              </label>
                              <input
                                type="email"
                                name="email"
                                placeholder="Email"
                                id="CustomerEmail"
                                defaultValue=""
                                required=""
                                onChange={handleChangeEmail}
                                onBlur={handleOnBlurEmail}
                              />
                            </div>
                          </div>
                          <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                            <div className="form-group">
                              <label
                                htmlFor="CustomerPassword"
                                className="d-none"
                              >
                                Password <span className="required">*</span>
                              </label>
                              <input
                                type="password"
                                name="password"
                                placeholder="Password"
                                id="CustomerPassword"
                                defaultValue=""
                                required=""
                                onChange={handlePassword}
                                onBlur={handleOnBlurPassword}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="row">
                          <div className="text-left col-12 col-sm-12 col-md-12 col-lg-12">
                            <p className="d-flex-center">
                              <input
                                type="submit"
                                className="btn rounded me-auto"
                                defaultValue="Sign In"
                                onClick={handleSubmit}
                              />
                              <a href="forgot-password.html">
                                Forgot your password?
                              </a>
                            </p>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              {/*End Main Content*/}
            </div>
            {/*End Container*/}
          </div>
          <Toaster limit={1} />
        </>
        {/* <Footer /> */}
      </div>
    </>
  );
}
export default Login;

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "./Header";
import Footer from "./Footer";
import moment from "moment";
import * as myConstList from "./BaseUrl";
import { Modal } from "react-bootstrap";
import Moment from "moment";

const baseUrl = myConstList.baseUrl;

function ActiveOrders() {
  const [data, setData] = useState([]);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [singleOrderData, setSingleOrderData] = useState([]);

  useEffect(() => {
    orders();
  }, []);

  const orders = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios
      .post(baseUrl + "/frontapi/activeOrders", {}, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          setData(resp.data);
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const dataTr = () => {
    let html = [];
    data.map(function (value, i) {
      let status = "";
      if (
        value.status === "0" ||
        value.status === null ||
        value.status === "1"
      ) {
        status = "Pending";
      }

      return html.push(
        <tr
          className="cart__row border-bottom line1 cart-flex border-top"
          key={value.id}
        >
          <td className="cart__price-wrapper cart-flex-item text-center small--hide">
            {value.id}
          </td>
          <td className="cart__update-wrapper cart-flex-item text-end text-md-center">
            INR {value.amount}
          </td>
          <td className="cart__update-wrapper cart-flex-item text-end text-md-center">
            {status}
          </td>
          <td className="cart-price cart-flex-item text-center small--hide">
            {moment(value.updateAt).format("lll")}
          </td>
          <td className="cart-price cart-flex-item text-center small--hide">
            <a
              href="#!"
              className="btn btn-primary"
              onClick={() => openDetailsModal(value.id)}
            >
              View Details
            </a>
          </td>
        </tr>
      );
    });
    return html;
  };

  const openDetailsModal = (id) => {
    setIsDetailsModalOpen(true);
    const config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("jwtToken")}`,
      },
    };
    let data = {
      id: id,
    };
    axios
      .post(baseUrl + "/frontapi/get-activeorder-details", data, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === true) {
          setSingleOrderData(resp.data);
        }
      });
  };

  const productsDetailsHtml = () => {
    const html = [];
    singleOrderData.map((item, i) => {
      return html.push(
        <tr key={item.name}>
          <td>{item.name}</td>
          <td>{item.price}</td>
          <td>{item.quantity}</td>
          <td>{item.gst}</td>
          <td>{item.gstAmount}</td>
          <td>{item.subTotal}</td>
          {/* <td>{item.order_status}</td> */}
          <td>{Moment(item.createAt).format("lll")}</td>
        </tr>
      );
    });
    return html;
  };

  const closeShowEditModel = () => {
    setIsDetailsModalOpen(false);
  };

  return (
    <>
      <Header />
      <div id="page-content">
        {/*Collection Banner*/}
        <div className="collection-header">
          <div className="collection-hero">
            <div className="collection-hero__image" />
            <div className="collection-hero__title-wrapper container">
              <h1 className="collection-hero__title">Active Order</h1>
              <div className="breadcrumbs text-uppercase mt-1 mt-lg-2">
                <a href="../index.html" title="Back to the home page">
                  Home
                </a>
                <span>|</span>
                <span className="fw-bold">Active Order</span>
              </div>
            </div>
          </div>
        </div>
        <div className="container">
          <div className="row">
            <div className="col-12 main-col">
              <table className="cart active-order-table align-middle">
                <thead className="cart__row cart__header small--hide">
                  <tr>
                    <th className="text-center">Order Id</th>
                    <th className="text-center">Price</th>
                    <th className="text-center">Status</th>
                    <th className="text-center">Date of Order</th>
                    <th className="text-center">View Details</th>
                  </tr>
                </thead>
                <tbody>{dataTr()}</tbody>
              </table>
            </div>
          </div>
          <Modal
            className="modal-update"
            show={isDetailsModalOpen}
            onHide={closeShowEditModel}
          >
            <Modal.Header closeButton>
              <Modal.Title className="m-0"> View details</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="row">
                <div className="col-12 main-col">
                  <table className="cart active-order-table align-middle">
                    <thead className="cart__row cart__header small--hide">
                      <tr>
                        <th className="text-center">Product Name</th>
                        <th className="text-center">Price</th>
                        <th className="text-center">Quantity</th>
                        <th className="text-center">GST</th>
                        <th className="text-center">GST Amount</th>
                        <th className="text-center">Sub Total</th>
                        {/* <th className="text-center">Status</th> */}
                        <th className="text-center">Date of Order</th>
                      </tr>
                    </thead>
                    <tbody>{productsDetailsHtml()}</tbody>
                  </table>
                </div>
              </div>
            </Modal.Body>
          </Modal>
        </div>
        <Footer />
      </div>
    </>
  );
}
export default ActiveOrders;

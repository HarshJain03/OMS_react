import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "./Header";
import Footer from "./Footer";
import * as myConstList from "./BaseUrl";
const baseUrl = myConstList.baseUrl;

function Cart(props) {
  const [data, setData] = useState([]);
  const [refreshed, setRefreshed] = useState(new Date().getTime());
  const [disableBtn, setDisableBtn] = useState(false);

  useEffect(() => {
    productListByCart();
    getProductAttribute();
  }, [refreshed]);

  const DecreaseMargin = async (value) => {
    let params = {
      productId: value.id,
      cartId: value.cartId,
    };
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    setDisableBtn(true);
    setTimeout(() => {
      setDisableBtn(false);
    }, 1000);
    await axios
      .post(baseUrl + "/frontapi/deleteCartANDCheck", params, config)
      .then((res) => {
        var resp = res.data;

        if (resp.status) {
          productListByCart();
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const IncrementMargin = (value) => {
    let params = {
      productId: value.id,
      cartId: value.cartId,
      qty: 1,
    };
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    setDisableBtn(true);
    setTimeout(() => {
      setDisableBtn(false);
    }, 1000);
    axios
      .post(baseUrl + "/frontapi/update-cart", params, config)
      .then((res) => {
        var resp = res.data;

        if (resp.status) {
          productListByCart();
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const productListByCart = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios
      .post(baseUrl + "/frontapi/get-cart-by-userid", {}, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          setData(resp.data);
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };

  const getProductAttribute = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios
      .post(baseUrl + "/frontapi/getProductAttribute", {}, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          // setAttrubuteData(resp.data);
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };
  const deleteCartProduts = async (value) => {
    console.log("valuee", value);
    alert("Checkkk");
    // return
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    let params = {
      productId: value,
    };
    await axios
      .post(baseUrl + "/frontapi/deleteCartProduts", params, config)
      .then((res) => {
        var resp = res.data;
        console.log("deleteCartProduts", resp);
        if (resp.status) {
          setRefreshed(true);
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };
  const deleteCartByUserid = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };

    await axios
      .post(baseUrl + "/frontapi/deleteCartByUserid", {}, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status) {
          setRefreshed(true);
        } else {
          toast.dismiss();
          toast.error(resp.message);
        }
      });
  };
  let total = 0;
  const attributeCheck = (value) => {
    return value.att.map((element, index) => {
      return (
        <div className="cart__meta-text">
          {element.name + ":" + element.value}
          <br />
        </div>
      );
    });
  };
  const dataHtml = () => {
    const html = [];

    data.map((value, i) => {
      total = total + value.price * value.qty;

      return html.push(
        <tr className="cart__row border-bottom line1 cart-flex">
          <td className="cart-delete text-center small--hide">
            <button
              type="button"
              onClick={() => deleteCartProduts(value.id)}
              className="btn btn--secondary cart__remove remove-icon position-static"
            >
              <i className="icon an an-times-r" />
            </button>
          </td>
          <td className="cart__image-wrapper cart-flex-item">
            <a href="product-layout1.html">
              <img
                className="cart__image blur-up lazyload"
                src={baseUrl + "/static/" + value.image}
                alt="Weave Hoodie Sweatshirt"
                width={80}
              />
            </a>
          </td>
          <td className="cart__meta small--text-left cart-flex-item">
            <div className="list-view-item__title">
              <a href="product-layout1.html"> {value.name} </a>
            </div>
            {attributeCheck(value)}

            <div className="cart-price d-md-none">
              <span className="money fw-500">₹{value.price}</span>
            </div>
          </td>
          <td className="cart__price-wrapper cart-flex-item text-center small--hide">
            <span className="money">₹{value.price}</span>
          </td>
          <td className="cart__update-wrapper cart-flex-item text-end text-md-center">
            <div className="cart__qty d-flex justify-content-end justify-content-md-center">
              <div className="qtyField">
                <button
                  className="qtyBtn minus"
                  type="button"
                  onClick={() => DecreaseMargin(value)}
                  disabled={disableBtn}
                >
                  -
                </button>
                <input
                  className="cart__qty-input qty"
                  type="text"
                  name="updates[]"
                  defaultValue={value.qty}
                  value={value.qty}
                  pattern="[0-9]*"
                />
                <button
                  className="qtyBtn plus"
                  type="button"
                  onClick={() => IncrementMargin(value)}
                  disabled={disableBtn}
                >
                  +
                </button>
              </div>
            </div>
            <a
              href="#!"
              title="Remove"
              className="removeMb d-md-none d-inline-block text-decoration-underline mt-2 me-3"
            >
              Remove
            </a>
          </td>
          <td className="cart-price cart-flex-item text-center small--hide">
            <span className="money fw-500">₹{value.price * value.qty}</span>
          </td>
        </tr>
      );
    });
    return html;
  };
  return (
    <>
      <Header />
      <div id="page-content">
        <>
          <div className="collection-header">
            <div className="collection-hero">
              <div className="collection-hero__image" />
              <div className="collection-hero__title-wrapper container">
                <h1 className="collection-hero__title">Cart</h1>
                <div className="breadcrumbs text-uppercase mt-1 mt-lg-2">
                  <a href="/dashboard" title="Back to the home page">
                    Home
                  </a>
                  <span>|</span>
                  <span className="fw-bold">Cart</span>
                </div>
              </div>
            </div>
          </div>
          {/*End Collection Banner*/}
          {/*Main Content*/}
          <div className="container">
            {/*Cart Page*/}
            <div className="row">
              <div className="col-12 col-sm-12 col-md-12 col-lg-8 main-col">
                <form action="#" method="post" className="cart style2">
                  <table className="align-middle">
                    <thead className="cart__row cart__header small--hide">
                      <tr>
                        <th className="action">&nbsp;</th>
                        <th colSpan={2} className="text-start">
                          Product
                        </th>
                        <th className="text-center">Price</th>
                        <th className="text-center">Quantity</th>
                        <th className="text-center">Total</th>
                      </tr>
                    </thead>
                    <tbody>{dataHtml()}</tbody>
                    <tfoot>
                      <tr>
                        <td colSpan={3} className="text-start pt-3">
                          <a
                            href="#!"
                            className="btn btn--link d-inline-flex align-items-center btn--small p-0 cart-continue"
                          >
                            <i className="me-1 icon an an-angle-left-l" />
                            <span className="text-decoration-underline">
                              <Link to={"/dashboard"}>Continue shopping </Link>
                            </span>
                          </a>
                        </td>
                        <td colSpan={3} className="text-end pt-3">
                          <button
                            onClick={deleteCartByUserid}
                            type="button"
                            name="clear"
                            className="btn btn--link d-inline-flex align-items-center btn--small small--hide"
                          >
                            <i className="me-1 icon an an-times-r" />
                            <span className="ms-1 text-decoration-underline">
                              Clear Shoping Cart
                            </span>
                          </button>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </form>
              </div>
              <div className="col-12 col-sm-12 col-md-12 col-lg-4 cart__footer">
                <div className="cart_info">
                  <div className="cart-order_detail cart-col">
                    <div className="row">
                      <span className="col-6 col-sm-6 cart__subtotal-title">
                        <strong>Subtotal</strong>
                      </span>
                      <span className="col-6 col-sm-6 cart__subtotal-title cart__subtotal text-end">
                        <span className="money">₹{total}</span>
                      </span>
                    </div>
                    <Link
                      id="cartCheckout"
                      className="btn btn--small-wide rounded my-4 checkout"
                      to={"/checkout"}
                    >
                      Proceed To Checkout
                    </Link>
                    {/* </a> */}
                  </div>
                </div>
              </div>
            </div>
            {/*End Cart Page*/}
          </div>
          {/*End Main Content*/}
          {/*End Body Container*/}
        </>
        <Footer refreshed={refreshed} setRefreshed={setRefreshed} />
      </div>
    </>
  );
}
export default Cart;

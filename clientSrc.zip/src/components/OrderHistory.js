import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "./Header";
import Footer from "./Footer";
import moment from "moment";
import * as myConstList from "./BaseUrl";

const baseUrl = myConstList.baseUrl;

function OrderHistory() {
  const [data, setData] = useState([]);
  useEffect(() => {
    orders();
  }, []);

  const orders = async () => {
    const config = {
      headers: {
        "x-access-token": localStorage.getItem("jwtToken"),
      },
    };
    await axios.post(baseUrl + "/frontapi/orders", {}, config).then((resp) => {
      var resp = resp.data;
      if (resp.status) {
        setData(resp.data);
      } else {
        toast.dismiss();
        toast.error(resp.message);
      }
    });
  };

  const dataTr = () => {
    let html = [];
    data.map((value, i) => {
      var status = "";
      if (value.order_status == "0" || value.order_status == null) {
        status = "Pending";
      }
      if (value.order_status == "1") {
        status = "InProgress";
      }
      if (value.order_status == "2") {
        status = "Packing Complete";
      }
      if (value.order_status == "3") {
        status = "Out for Delivery";
      }
      if (value.order_status == "4") {
        status = "Delivered";
      }
      if (value.order_status == "5") {
        status = "Rejected";
      }
      html.push(
        <tr
          className="cart__row border-bottom line1 cart-flex border-top"
          key={i}
        >
          <td className="cart__image-wrapper cart-flex-item">
            <Link to={"/product-detail/" + value.product_Id}>
              <img
                className="img-fluid"
                src={baseUrl + "/static/" + value.image}
                alt=""
                width={80}
              />
            </Link>
          </td>
          <td className="cart__price-wrapper cart-flex-item text-center small--hide">
            {value.orderId}
          </td>
          <td className="cart__update-wrapper cart-flex-item text-end text-md-center">
            {value.name}
          </td>
          <td className="cart__update-wrapper cart-flex-item text-end text-md-center">
            {value.quantity}
          </td>
          <td className="cart__update-wrapper cart-flex-item text-end text-md-center">
            INR {value.subTotal}
          </td>
          <td className="cart__update-wrapper cart-flex-item text-end text-md-center">
            {status}
          </td>
          <td className="cart-price cart-flex-item text-center small--hide">
            {moment(value.updateAt).format("lll")}
          </td>
        </tr>
      );
    });
    return html;
  };

  return (
    <>
      <Header />
      <div id="page-content">
        {/*Main Content*/}
        <div className="collection-header">
          <div className="collection-hero">
            <div className="collection-hero__image" />
            <div className="collection-hero__title-wrapper container">
              <h1 className="collection-hero__title">Order History</h1>
              <div className="breadcrumbs text-uppercase mt-1 mt-lg-2">
                <a href="../index.html" title="Back to the home page">
                  Home
                </a>
                <span>|</span>
                <span className="fw-bold">Order History</span>
              </div>
            </div>
          </div>
        </div>
        {/*End Collection Banner*/}
        {/*Main Content*/}
        <div className="container">
          {/*Cart Page*/}
          <div className="row">
            <div className="col-12 main-col">
              <table className="cart active-order-table align-middle">
                <thead className="cart__row cart__header small--hide">
                  <tr>
                    <th className="text-center">Product</th>
                    <th className="text-center">Order Id</th>
                    <th className="text-center">Product Name</th>
                    <th className="text-center">Quantity</th>
                    <th className="text-center">Price</th>
                    <th className="text-center">Status</th>
                    <th className="text-center">Date of Order</th>
                  </tr>
                </thead>
                <tbody>{dataTr()}</tbody>
              </table>
            </div>
          </div>
        </div>
        {/*End Main Content*/}
        <Footer />
      </div>
    </>
  );
}
export default OrderHistory;

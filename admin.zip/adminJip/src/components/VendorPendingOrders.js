import React, { useState, useEffect, Fragment } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "./Header";
import Navbar from "./Navbar";
import Footer from "./Footer";
import ReactDatatable from "@mkikets/react-datatable";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";

import * as myConstList from "./BaseUrl";
const baseUrl = myConstList.baseUrl;

const VendorPendingOrders = () => {
  const [data, setData] = useState([]);
  const [adRecords, setAdRecords] = useState([]);
  const [records, setRecords] = useState([]);
  const [refreshed, setRefreshed] = useState(false);

  useEffect(() => {
    productData();
  }, [refreshed]);

  const columns = [
    {
      key: "Sr No.",
      text: "Sr No.",
      className: "cust_id",
      align: "left",
      sortable: true,
      cell: (row, index) => index + 1,
    },
    {
      key: "name",
      text: "Product Name",
      className: "pn",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>{record.name === null ? "N/A" : record.name}</Fragment>
        );
      },
    },
    {
      key: "against_order_id",
      text: "Against Order",
      className: "ao",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>{record.against_order_id === null ? "NO" : "YES"}</Fragment>
        );
      },
    },
    {
      key: "price",
      text: "Price",
      className: "phoneno",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>{record.price === null ? "N/A" : record.price}</Fragment>
        );
      },
    },
    {
      key: "quantity",
      text: "Quantity",
      className: "phoneno",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>
            {record.quantity === null ? "N/A" : record.quantity}
          </Fragment>
        );
      },
    },
    {
      key: "total",
      text: "Total",
      className: "phoneno",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>
            {record.total === null ? "N/A" : record.total + " INR"}
          </Fragment>
        );
      },
    },
    {
      key: "orderType",
      text: "Order Type",
      className: "otype",
      align: "left",
      sortable: true,
      cell: (record) => {
        return <Fragment>{record.orderType}</Fragment>;
      },
    },

    {
      key: "prod",
      text: "Image",
      className: "prodimg",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>
            {record.product_file === null ? (
              "N/A"
            ) : (
              <a
                href={baseUrl + "/static/customizeImage/" + record.product_file}
                target="_blank"
                rel="noreferrer"
                className="btn btn-primary"
              >
                {!record.product_file.match(/\.(jpg|jpeg|png|gif)$/) ? (
                  "View File"
                ) : (
                  <img
                    src={
                      baseUrl + "/static/customizeImage/" + record.product_file
                    }
                    alt=""
                    className="img-fluid"
                  />
                )}
              </a>
            )}
          </Fragment>
        );
      },
    },
    {
      key: "status",
      text: "Status",
      className: "detail",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>
            <select
              className="form-control"
              value={record.status}
              onChange={(e) => changeStatusProduct(e, record)}
            >
              <option>Select</option>
              <option value="1">In Progress</option>
              <option value="2">Completed</option>
              <option value="3">Rejected</option>
            </select>
          </Fragment>
        );
      },
    },
  ];

  const adColumns = [
    {
      key: "Sr No.",
      text: "Sr No.",
      className: "",
      align: "left",
      sortable: true,
      cell: (row, index) => index + 1,
    },

    {
      key: "id",
      text: "Order Id",
      className: "cust_name",
      align: "left",
      sortable: true,
    },
    {
      key: "name",
      text: "Product Name",
      className: "pn",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>{record.name === null ? "N/A" : record.name}</Fragment>
        );
      },
    },
    {
      key: "against_order_id",
      text: "Against Order",
      className: "ao",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>{record.against_order_id === null ? "NO" : "YES"}</Fragment>
        );
      },
    },
    {
      key: "price",
      text: "Price",
      className: "phoneno",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>{record.price === null ? "N/A" : record.price}</Fragment>
        );
      },
    },
    {
      key: "quantity",
      text: "Quantity",
      className: "phoneno",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>
            {record.quantity === null ? "N/A" : record.quantity}
          </Fragment>
        );
      },
    },
    {
      key: "total",
      text: "Total",
      className: "phoneno",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>
            {record.total === null ? "N/A" : record.total + " INR"}
          </Fragment>
        );
      },
    },
    {
      key: "Detail",
      text: "Detail",
      className: "detail",
      align: "left",
      sortable: true,
      cell: (record) => {
        return (
          <Fragment>
            <Link to={"/vendor-order-details/" + record.id}>
              <img src="assets/images/view-icon.png" alt="" class="img-fluid" />
            </Link>
          </Fragment>
        );
      },
    },
  ];

  const config = {
    page_size: 10,
    length_menu: [10, 20, 50],
    filename: "Fund Request List",
    no_data_text: "No user found!",
    button: {
      print: true,
      csv: true,
    },
    language: {
      // length_menu: "Show MENU result per page",
      filter: "Filter in records...",
      // info: "Showing START to END of TOTAL records",
      pagination: {
        first: "First",
        previous: "Previous",
        next: "Next",
        last: "Last",
      },
    },
    show_length_menu: true,
    show_filter: true,
    show_pagination: true,
    show_info: true,
  };
  const pageChange = (pageData) => {
    console.log("OnPageChange", pageData);
  };

  const productData = () => {
    const config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("jwtToken")}`,
      },
    };
    let requestData = { status: 0, orderType: "vendor" };
    axios
      .post(baseUrl + "/frontapi/order-data", requestData, config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === false) {
          toast.dismiss();
          toast.error(resp.message);
          return;
        }
        if (resp.status === true) {
          setData(resp.data);
          setAdRecords(resp.data);
          setRecords(resp.data);
        }
      });
  };

  const VendorDataHtml = () => {
    const html = [];
    if (data.length > 0) {
      data.map((value, i) => {
        return html.push(
          <tr>
            <td>{i + 1}</td>
            <td>{value.name === null ? "N/A" : value.name}</td>
            <td>{value.against_order_id === null ? "NO" : "YES"}</td>
            <td>{value.price === null ? "N/A" : value.price}</td>
            <td>{value.quantity === null ? "N/A" : value.quantity}</td>
            <td>{value.total === null ? "N/A" : value.total}</td>
            <td>{value.orderType}</td>
            <td className="product-img">
              {value.product_file === null ? (
                "N/A"
              ) : (
                <a
                  href={
                    baseUrl + "/static/customizeImage/" + value.product_file
                  }
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-primary"
                >
                  {!value.product_file.match(/\.(jpg|jpeg|png|gif)$/) ? (
                    "View File"
                  ) : (
                    <img
                      src={
                        baseUrl + "/static/customizeImage/" + value.product_file
                      }
                      alt=""
                      className="img-fluid"
                    />
                  )}
                </a>
              )}
            </td>
            {value.product_file === null ? (
              <td>N/A</td>
            ) : (
              <td>
                {value.sample_file == null ? (
                  <input type={"file"} className="form-control" />
                ) : (
                  <img alt="" />
                )}
              </td>
            )}
            <td>
              <select
                className="form-control"
                value={value.status}
                onChange={(e) => changeStatusProduct(e, value)}
              >
                <option>Select</option>
                <option value="1">In Progress</option>
                <option value="2">Completed</option>
                <option value="3">Rejected</option>
              </select>
            </td>
          </tr>
        );
      });
    } else {
      html.push(
        <tr>
          <td colSpan="6">
            <h5>No Pending Orders</h5>
          </td>
        </tr>
      );
    }

    return html;
  };

  const updateStatus = (record) => {
    const config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("jwtToken")}`,
      },
    };
    axios
      .post(baseUrl + "/frontapi/change-vendororder-status", record,config)
      .then((res) => {
        var resp = res.data;
        if (resp.status === true) {
          toast.dismiss();
          toast.success(resp.message);
          productData();
          return false;
        }
        toast.dismiss();
        toast.error(resp.message);
      });
  };

  const checkCall = () => {
    return false;
  };

  const Conn = (data) => {
    confirmAlert({
      title: "Confirm to submit",
      message: "Are you sure to do this.",
      buttons: [
        {
          label: "Yes",
          onClick: () => updateStatus(data),
        },
        {
          label: "No",
          onClick: () => checkCall(),
        },
      ],
    });
  };

  const changeStatusProduct = (e, value) => {
    let data = {
      orderId: value.id,
      status: e.target.value,
      quantity: value.quantity,
      productId: value.product_id,
    };
    if (e.target.value) {
      Conn(data);
      return false;
    }
  };

  const dataHtml = () => {
    const html = [];
    if (data.length > 0) {
      data.map(function (value, i) {
        html.push(
          <tr>
            <td>{i + 1}</td>
            <td>{value.id}</td>
            <td>{value.name === null ? "N/A" : value.name}</td>
            <td>{value.against_order_id === null ? "NO" : "YES"}</td>
            <td>{value.price === null ? "N/A" : value.price}</td>
            <td>{value.quantity === null ? "N/A" : value.quantity}</td>
            <td>{value.total === null ? "N/A" : value.total + " INR"}</td>
            <td>
              <Link to={"/vendor-order-details/" + value.id}>
                <img
                  src="assets/images/view-icon.png"
                  alt=""
                  class="img-fluid"
                />
              </Link>
            </td>
          </tr>
        );
      });
    } else {
      html.push(
        <tr>
          <td colSpan="6">
            <h5>No Pending Orders</h5>
          </td>
        </tr>
      );
    }

    return html;
  };

  return (
    <div id="layout-wrapper">
      <Header />
      <Navbar />
      <div class="main-content">
        <div class="page-content">
          <div class="container-fluid">
            <div class="section-heading">
              <h2 class="text-black">
                <b>VENDOR PENDING ORDERS</b>
              </h2>
            </div>
            <div class="row">
              <div class="col-xxl-5">
                <div class="product-list-outer customer-list-outer">
                  {localStorage.getItem("userType") === "Vendor" ? (
                    <ReactDatatable
                      config={config}
                      records={records}
                      columns={columns}
                      onPageChange={pageChange}
                    />
                  ) : (
                    // <table class="w-100 border">
                    //   <tr>
                    //     <th>S.No.</th>
                    //     <th>Product Name</th>
                    //     <th>Against Order</th>
                    //     <th>Price</th>
                    //     <th>Quantity</th>
                    //     <th>Total</th>
                    //     <th>Order Type</th>
                    //     <th>Customize File</th>
                    //     <th>Upload Sample File</th>
                    //     <th>Status</th>
                    //   </tr>
                    //   {VendorDataHtml()}
                    // </table>
                    <ReactDatatable
                      config={config}
                      records={adRecords}
                      columns={adColumns}
                      onPageChange={pageChange}
                    />

                    // <table class="w-100 border">
                    //   <tr>
                    //     <th>S.No.</th>
                    //     <th>Order Id</th>
                    //     <th>Product Name</th>
                    //     <th>Against Order</th>
                    //     <th>Price</th>
                    //     <th>Quantity</th>
                    //     <th>Total</th>
                    //     <th>Detail</th>
                    //   </tr>
                    //   {dataHtml()}
                    // </table>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        <ToastContainer limit={1} />
        <Footer refreshed={refreshed} setRefreshed={setRefreshed} />
      </div>
    </div>
  );
};

export default VendorPendingOrders;
